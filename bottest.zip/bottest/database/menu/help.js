const help = (pushname, prefix, botName, ownerName, reqXp, uangku) => {
        return `
「 *${botName}* 」

◪ *USER INFO*
  ❏ Nome: ${pushname}
  ❏ XP: ${reqXp}
  ❏ Dinheiro: ${uangku}
  ❏ Registrado: ✔️
◪ *BOT INFO*
  ❏ Prefix: 「  ${prefix}  」
  ❏ Criador: ${ownerName}
  ❏ Versão: 0.0.4
◪ *SOBRE*
  │
  ├─ ❏ ${prefix}info
  ├─ ❏ ${prefix}blocklist
  ├─ ❏ ${prefix}chatlist
  ├─ ❏ ${prefix}ping
  └─ ❏ ${prefix}bugreport
◪ *MENU*
  │
  ├─ ❏ ${prefix}sticker
  ├─ ❏ ${prefix}srickergif
  ├─ ❏ ${prefix}Play
  ├─ ❏ ${prefix}sei la kkkk usa so esses `
}
exports.help = help
