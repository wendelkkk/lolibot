exports.wait = () => {
	return`*「 WAIT 」 AGUARDE UM POUCO.. *`
}

exports.succes = () => {
	return`*「 SUCESSO 」*`
}

exports.lvlon = () => {
	return`*LEVEL 「 ATIVADO 」 *`
}

exports.lvloff = () => {
	return`*LEVEL 「 DESATIVADO 」*`
}

exports.lvlnul = () => {
	return`*LEVEL 0 TAQUIPARIU KKKKKK*`
}

exports.lvlnoon = () => {
	return`*O NÍVEL DO GRUB NÃO FOI ATIVADO*`
}

exports.noregis = () => {
	return`*「 NÃO REGISTRADO 」*\n\n*Para ter acesso ao menu você tem que se cadastrar\n*Digite: ${prefix}registrar Nome|idade* \n*ex: ${prefix}registrar Wendel|18*\n\nTEM QUE DEIXAR TER O " | " SEM AS ASPAS`
}

exports.rediregis = () => {
	return`*「 JÁ REGISTRADO 」*\n\n*você se registrou no banco de dados do Bot*`
}

exports.stikga = () => {
	return`*sim, falhou tente repetir em alguns momentos*`
}

exports.linkga = () => {
	return`*desculpe link inválido*`
}

exports.groupo = () => {
	return`*「COMANDO SO FUNCIONA EM SÓ GRUPO」*`
}

exports.ownerb = () => {
	return`*「OWNER BOT APENAS」*`
}

exports.ownerg = () => {
	return`*「SOMENTE PROPRIETÁRIOS DO BOT」*`
}

exports.admin = () => {
	return`*「SOMENTE A ADMINISTRAÇÃO DO GRUPO」*`
}

exports.badmin = () => {
	return`*「O BOT DEVE SER ADMINISTRADOR」*`
}

exports.nsfwoff = () => {
	return`*NSFW EM ATIVO*`
}

exports.bug = () => {
	return`*Problemas foram relatados ao proprietário do BOT, relatórios falsos não serão respondidos*`
}

exports.wrongf = () => {
	return`*Formato incorreto/texto em branco*`
}

exports.clears = () => {
	return`*Tudo limpo 😎🤙*`
}

exports.pc = () => {
	return`*「 CADASTRO 」*\n\n para saber se você se cadastrou, verifique a mensagem que enviei \n\nNOTE:\n*se você não entendeu a mensagem. significa que você não salvou o número do seu bot*`
}

exports.registered = (namaUser, umurUser, serialUser, time, sender) => {
	return`*「 DATA DE REGISTRO *LOLI NAZISTA*」*\n\nvocê se registrou com os dados \n\n┏━⊱Nome\n┗⊱${namaUser}\n┏━⊱Numero\n┗⊱wa.me/${sender.split("@")[0]}\n┏━⊱idade\n┗⊱${umurUser}\n┏━⊱Hora de registro\n┗⊱${time}\n\n┏━❉ *NS* ❉━\n┣⊱${serialUser}\n┗⊱NOTA : não se esqueça deste número porque é importante:v`
}

exports.cmdnf = (prefix, command) => {
	return`comando *${prefix}${command}* não encontrado\tente escrever *${prefix}menu*`
}

exports.owneresce = (pushname) => {
	return`*Desculpe, mas ${pushname} So funciona com o dono (owner script)*`
}

exports.reglevelaha = (command, pushname, getLevelingLevel, sender, aha) => {
	return`*Desculpa ${pushname} seu nível não é suficiente*\n\n*┏⊱Seu level : ${getLevelingLevel(sender)}*\n*┣⊱ tipo de comando : ${command}*\n*┗⊱requisitos de nível : ${aha}*\n\n_NOTE : CHAT / SEMPRE PARA RECEBER XP_`
}

exports.reglevelahb = (command, pushname, getLevelingLevel, sender, ahb) => {
	return`*Desculpa ${pushname} seu nível não é suficiente*\n\n*┏⊱Seu level : ${getLevelingLevel(sender)}*\n*┣⊱ tipo de comando : ${command}*\n*┗⊱requisitos de nível : ${ahb}*\n\n_NOTE : CHAT/SEMPRE PARA OBTER XP_`
}

exports.reglevelahc = (command, pushname, getLevelingLevel, sender, ahc) => {
	return`*Desculpa ${pushname} seu nível não é suficiente*\n\n*┏⊱Seu level: ${getLevelingLevel(sender)}*\n*┣⊱tipo de comando : ${command}*\n*┗⊱requisitos de nível : ${ahc}*\n\n_NOTE : CHAT/SEMPRE PARA OBTER XP_`
}

exports.reglevelahd = (command, pushname, getLevelingLevel, sender, ahd) => {
	return`*Desculpa ${pushname} seu nível não é suficiente*\n\n*┏⊱Seu level : ${getLevelingLevel(sender)}*\n*┣⊱tipo de comando : ${command}*\n*┗⊱requisitos de nível : ${ahd}*\n\n_NOTE : CHAT/SEMPRE PARA OBTER XP_`
}

exports.reglevelahe = (command, pushname, getLevelingLevel, sender, ahe) => {
	return`*Desculpa ${pushname} seu nível não é suficiente*\n\n*┏⊱Seu level : ${getLevelingLevel(sender)}*\n*┣⊱tipo de comando : ${command}*\n*┗⊱requisitos de nível: ${ahe}*\n\n_NOTE : CHAT/SEMPRE PARA OBTER XP_`
}

exports.reglevelahf = (command, pushname, getLevelingLevel, sender, ahf) => {
	return`*Desculpa ${pushname} seu nível não é suficiente*\n\n*┏⊱Seu level : ${getLevelingLevel(sender)}*\n*┣⊱tipo de comando : ${command}*\n*┗⊱requisitos de nível : ${ahf}*\n\n_NOTE : CHAT/SEMPRE PARA OBTER XP_`
}

exports.menu = (pushname, prefix, getLevelingLevel, getLevelingXp, sender, reqXp, _registered, uangku) => { 
	return `
╭══─⊱ ❰ *SOBRE USUARIO* ❱ ⊰─══
╠☞ *Nome* : ${pushname}
╠☞ *Numero* : wa.me/${sender.split("@")[0]}
╠☞ *O teu dinheiro* : Rp${uangku}
╠☞ *XP* : ${getLevelingXp(sender)}/${reqXp}
╠☞ *Level* : ${getLevelingLevel(sender)}
╠☞ *User register* : ${_registered.length}
╠☞ *SN* : ${serialUser}
╰════─⊱  ⸨ *WENDEL KKKK* ⸩  ⊰─════╯

          
▬▭▬▭▬▭▬▭▬▭▬▭▬
●⧐ *Spam: bloqueio automático!*
●⧐ *Dê uma pausa de 5 segundos ao usá-lo !!*
●⧐ *Bug/Error Por favor, fala com o dono do bot*
●⧐ *BLA BLA BLA FDS*
●⧐ *Por favor, seja paciente com os bugs!*
▬▭▬▭▬▭▬▭▬▭▬▭▬

╭══─⊱ ❰ *MAKER MENU* ❱ ⊰─══➤
╠☞ *${prefix}sticker* /img e gif
╠☞ *${prefix}figurinha*
║
╠══─⊱ ❰ *FUL MENU* ❱ ⊰─════➤
╠☞ *${prefix}minerar*
╠☞ *${prefix}Ping*
╠☞ *${prefix}falar* (pt) (texto)
╠☞ *${prefix}Play* /DESATIVADO
╠☞ *${prefix}evento* [1/0]
╠☞ *${prefix}botfdp*
╠☞ *${prefix}registrar* 
╠☞ *${prefix}pegaradm*
║
╠══─⊱ ❰ *LIMIT MENU* ❱ ⊰─═══➤
╠☞ *COMANDOS EM TESTE*
║
╠☞ *${prefix}limite* 
╠☞ *${prefix}comprarlimite*
╠☞ *${prefix}bolsa* 
║
╠══─⊱ ❰ *FUN MENU* ❱ ⊰─═══➤
╠☞ *COMANDO EM TESTE*
║
╠☞ *${prefix}pokemon*
╠☞ *${prefix}anjing*
╠☞ *${prefix}1cak*
║
╠══─⊱ ❰ *GRUPO MENU* ❱ ⊰─══➤
╠☞ *${prefix}hidetag*
╠☞ *${prefix}grouplist*
╠☞ *${prefix}level*
╠☞ *${prefix}linkgc*
╠☞ *${prefix}Marcar*
╠☞ *${prefix}setpp*
╠☞ *${prefix}add*
╠☞ *${prefix}kick*
╠☞ *${prefix}setname*
╠☞ *${prefix}setdesc*
╠☞ *${prefix}tiraradm*
╠☞ *${prefix}daadm*
╠☞ *${prefix}picudos*
╠☞ *${prefix}grupo* [abrir/fechar]
╠☞ *${prefix}leveling* [ativar/desativar]
╠☞ *${prefix}nsfw* [1/0]
╠☞ *${prefix}welcome* [1/0]
║
╠══─⊱ ❰ *OWNER MENU* ❱ ⊰─══➤
╠☞ *${prefix}kickall*
╠☞ *${prefix}setreply*
╠☞ *${prefix}setprefix*
╠☞ *${prefix}limpar*
╠☞ *${prefix}block*
╠☞ *${prefix}unblock*
╠☞ *${prefix}clone*
╠☞ *${prefix}setppbot*
║
╠══─⊱ ❰ *LOLI NAZISTA* ❱ ⊰─══➤
║
╰════─⊱  ⸨ *WENDEL DNV KKKK* ⸩  ⊰─════╯
`
}

exports.levelup = (pushname, sender, getLevelingXp,  getLevel, getLevelingLevel) => {
	return`
*「 LEVEL UP 」*

┏⊱ *Nome* : ${pushname}
┣⊱ *Numero* : wa.me/${sender.split("@")[0]}
┣⊱ *Xp* : ${getLevelingXp(sender)}
┗⊱ *Level* : ${getLevel} ⊱ ${getLevelingLevel(sender)}
`}
 
exports.limitend = (pushname) => {
	return`*Desculpa ${pushname} O limite de hoje expira*\n*O limite é zerado a cada hora 24:00*`
}

exports.limitcount = (limitCounts) => {
	return`
*「 LIMIT COUNT 」*
o resto do seu limite : ${limitCounts}

NOTE : para chegar ao limite. pode passar de nível ou limite de capacidade`
}

exports.satukos = () => {
	return`*Digite 1 para habilitar ou 0 para desabilitar`
}

exports.uangkau = (pushname, sender, uangkau) => {
	return`*┏⊱ *「 ATM 」* ━┓\n┣⊱ *Nome* : ${pushname}\n┣⊱ *Número* : ${sender.split("@")[0]}\n┣⊱ *Dinheiro* : ${uangkau}\n┗━━━━━━━━━━`
}
