exports.noregis = () => {
        return `*──「 REGISTRA-SE 」──\nOlá Oni-chan!😊\nVocê ainda não se Registrou, Vamos registrar primeiro... \n\nComando: ${prefix}register Nome|Idade\nExemplo: ${prefix}register Wendel|18\n\n *TEM QUE TER O "|" PRA SEPARAR (SEM ASPAS).``
}

exports.rediregis = () => {
        return `*「 REGISTRADO 」*\n\n*você se registrou no banco de dados do bot*`
}

exports.wrongf = () => {
        return`*Formato incorreto/texto em branco*`
}

exports.clears = () => {
        return`*Tudo limpo, parece minha roula*`
}

exports.pc = () => {
        return`*「 CADASTRO 」*\n\n para saber se você se cadastrou, verifique a mensagem que enviei \n\nNOTA:\n*se você não entendeu a mensagem. significa que você não salvou o número do seu bot😔*`
}

exports.registered = (namaUser, umurUser, serialUser, time, sender) => {
        return`*「 DADOS DE REGISTRO 」*\n\nvocê se registrou com os dados \n\n◪ *DADOS* \n  │ \n  ├─ ❏ Nome : ${namaUser} \n  ├─ ❏ Número : wa.me/${sender.split("@")[0]} \n  ├─ ❏ Idade : ${umurUser} \n  ├─ ❏ Hora do Registro: ${time} \n  │ \n └─ ❏ NS : ${serialUser} \n\n ❏ NOTE : \nNÃO ESQUEÇA ESTE NÚMERO PORQUE É IMPORTANTE:v`
}

exports.cmdnf = (prefix, command) => {
        return`comando *${prefix}${command}* não encontrado\tente escrever *${prefix}menu*`
}

exports.owneresce = (pushname) => {
        return`*Desculpe, mas ${pushname} não é dono do script*`
}

exports.limitend = (pushname) => {
        return`*Desculpa ${pushname} O limite de hoje Acabou*\n*O limite é zerado a cada 24:00 horas*`
}

exports.limitcount = (limitCounts) => {
        return`
*「 LIMIT COUNT 」*
o resto do seu limite : ${limitCounts}

NOTE : para obter o mais limite. vc tem que passar de level ou comprar limite`
}

exports.satukos = () => {
        return`*Adicionar parâmetro 1/habilitar ou 0/desabilitar
}

exports.uangkau = (pushname, sender, uangkau) => {
        return`◪ *ATM*\n  ❏ *Nome* : ${pushname}\n  ❏ *Número* : ${sender.split("@")[0]}\n  ❏ *Dinheiro* : ${uangkau}`
}
