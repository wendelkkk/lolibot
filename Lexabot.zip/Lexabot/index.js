

//--Whatsapp Connecting
const {
  WAConnection,
  MessageType,
  Presence,
  Mimetype,
  GroupSettingChange,
  MessageOptions,
  WALocationMessage,
  WA_MESSAGE_STUB_TYPES,
  ReconnectMode,
  ProxyAgent,
  waChatKey,
  mentionedJid,
  processTime,
  ChatModification,
} = require('@adiwajshing/baileys');
//--

//--File js
const {color, bgcolor} = require('./lib/color');
const {bahasa} = require('./src/bahasa');
const {negara} = require('./src/kodenegara');
const {wait, simih, getBuffer, h2k, generateMessageID, getGroupAdmins, getRandom, banner, start, info, success, clos } = require('./lib/functions');
const {fetchJson} = require('./lib/fetcher');
const {recognize} = require('./lib/ocr');

//--

//--Pakage Npm
const fs = require('fs');
const moment = require('moment-timezone');
const {exec} = require('child_process');
const kagApi = require('@kagchi/kag-api');
const fetc = require('node-fetch');
const tiktod = require('tiktok-scraper');
const ffmpeg = require('fluent-ffmpeg');
const {removeBackgroundFromImageFile} = require('remove.bg');
const imgbb = require('imgbb-uploader');
const lolis = require('lolis.life');
const loli = new lolis();
const speed = require('performance-now');
const cd = 4.32e+7 ;
const crypto = require('crypto');
const qrcode = require("qrcode-terminal");
const axios = require('axios');
//--

//--File json bot
const welkom = JSON.parse(fs.readFileSync('./data/welkom.json'));
const up = JSON.parse(fs.readFileSync('./data/settings.json'));
const samih = JSON.parse(fs.readFileSync('./data/simi.json'))
//--

//--File json temp
const setiker = JSON.parse(fs.readFileSync('./temp/stik.json'))
const videonye = JSON.parse(fs.readFileSync('./temp/vid.json'))
const audionye = JSON.parse(fs.readFileSync('./temp/vn.json'))
const imagenye = JSON.parse(fs.readFileSync('./temp/image.json'))

//--File json user
const _limit = JSON.parse(fs.readFileSync('./datauser/limit.json'));
const uang = JSON.parse(fs.readFileSync('./datauser/uang.json'));
const _registered = JSON.parse(fs.readFileSync('./datauser/registered.json'));
//--

//--Setting
prefix = up.prefix
const limitawal = up.limit;
const memberlimit = up.memberlimit;
const cr = up.cr;
const hargalimit = up.hargalimit;
const NamaBot = up.NamaBot;
const Ig = up.Ig;
const Wa1 = up.Wa1;
const Wa2 = up.Wa2;
const Ovo = up.Ovo;
const Pulsa = up.Pulsa;
const Dana = up.Dana;
const blocked = [];
const ownerNumber = up.ownerNumber;
//--

//--Apikey
BarBarKey = up.BarBarKey;
vKey = up.Vhtearkey;
viKey = up.Vinzapi
meKey = up.Itsmeikyapi
lolKey = up.LolHumanKey
//--

//--Contato
const vcard = 'BEGIN:VCARD\n'
            + 'VERSION:3.0\n' 
            + 'FN:Wendel Lindo\n' // Seu nome
            + 'ORG:totoso;\n' // Nome do bot
            + 'TEL;type=CELL;type=VOICE;waid=558287515844:+55 82 8751-5844\n' //Nomor whatsapp kamu
            + 'END:VCARD'

//--Datauser

const getLimit = (sender) => {
  let position = false
  Object.keys(limit).forEach ((i) => {
if (limit[position].id === sender) {
  position = i
}
  })
  if (position !== false) {
return limit[position].limit
  }
}

const getRegisteredRandomId = () => {
  return _registered[Math.floor(Math.random() * _registered.length)].id
}

const addRegisteredUser = (userid, sender, age, time, serials) => {
  const obj = {
id: userid,
name: sender,
age: age,
time: time,
serial: serials
  }
  _registered.push(obj)
  fs.writeFileSync('./datauser/registered.json', JSON.stringify(_registered))
}

const createSerial = (size) => {
  return crypto.randomBytes(size).toString('hex').slice(0, size)
}

const checkRegisteredUser = (sender) => {
  let status = false
  Object.keys(_registered).forEach((i) => {
if (_registered[i].id === sender) {
  status = true
}
  })
  return status
}


const addATM = (sender) => {
  const obj = {
id: sender, uang: 0
  }
  uang.push(obj)
  fs.writeFileSync('./datauser/uang.json',
JSON.stringify(uang))
}

const addKoinUser = (sender, amount) => {
  let position = false
  Object.keys(uang).forEach((i) => {
if (uang[i].id === sender) {
  position = i
}
  })
  if (position !== false) {
uang[position].uang += amount
fs.writeFileSync('./datauser/uang.json', JSON.stringify(uang))
  }
}

const checkATMuser = (sender) => {
  let position = false
  Object.keys(uang).forEach((i) => {
if (uang[i].id === sender) {
  position = i
}
  })
  if (position !== false) {
return uang[position].uang
  }
}

const bayarLimit = (sender, amount) => {
  let position = false
  Object.keys(_limit).forEach((i) => {
if (_limit[i].id === sender) {
  position = i
}
  })
  if (position !== false) {
_limit[position].limit -= amount
fs.writeFileSync('./datauser/limit.json', JSON.stringify(_limit))
  }
}

const confirmATM = (sender, amount) => {
  let position = false
  Object.keys(uang).forEach((i) => {
if (uang[i].id === sender) {
  position = i
}
  })
  if (position !== false) {
uang[position].uang -= amount
fs.writeFileSync('./datauser/uang.json', JSON.stringify(uang))
  }
}

const limitAdd = (sender) => {
  let position = false
  Object.keys(_limit).forEach((i) => {
if (_limit[i].id == sender) {
  position = i
}
  })
  if (position !== false) {
_limit[position].limit += 1
fs.writeFileSync('./datauser/limit.json', JSON.stringify(_limit))
  }
}

//--Waktu
function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var second = Math.floor(seconds % 60);
  return `${pad(hours)}:${pad(minutes)}:${pad(second)}`;
}
//--

//--Whatsapp start connect
async function starts() {
	const Lxa = new WAConnection()
	Lxa.logger.level = 'warn'
	console.log(banner.string)
	Lxa.on('qr', () => {
		console.log(color('[','white'), color('!','red'), color(']','white'), color(' Scan the qr code above'))
	})

	fs.existsSync('./Lexa.json') && Lxa.loadAuthInfo('./Lexa.json')
	Lxa.on('connecting', () => {
		start('2', 'Connecting...')
	})
	Lxa.on('open', () => {
		success('2', 'Connected')
	})
	await Lxa.connect({timeoutMs: 30*1000})
        fs.writeFileSync('./Lexa.json', JSON.stringify(Lxa.base64EncodedAuthInfo(), null, '\t'))


	Lxa.on('group-participants-update', async (anu) => {
		if (!welkom.includes(anu.jid)) return
		try {
			const mdata = await Lxa.groupMetadata(anu.jid)
			console.log(anu)
			if (anu.action == 'add') {
				num = anu.participants[0]
				teks = `Oii @${num.split('@')[0]} Bem-vindo ao *${mdata.subject}* Digite ${prefix}verify para começar a usar o bot.`
				Lxa.sendMessage(mdata.id, teks, MessageType.text, { contextInfo: {"mentionedJid": [num]}})
			} else if (anu.action == 'remove') {
				num = anu.participants[0]
				teks = `Sayonara @${num.split('@')[0]}👋`
				Lxa.sendMessage(mdata.id, teks, MessageType.text, {contextInfo: {"mentionedJid": [num]}})
			}
		} catch (e) {
			console.log('Error : %s', color(e, 'red'))
		}
	})

	Lxa.on('CB:Blocklist', json => {
            if (blocked.length > 2) return
	    for (let i of json[1].blocklist) {
	    	blocked.push(i.replace('c.us','s.whatsapp.net'))
	    }
	})

	Lxa.on('chat-update', async (mek) => {
		try {
            if (!mek.hasNewMessage) return
            mek = mek.messages.all()[0]
			if (!mek.message) return
			if (mek.key && mek.key.remoteJid == 'status@broadcast') return
			if (mek.key.fromMe) return
			global.prefix
			global.blocked
			const content = JSON.stringify(mek.message)
			const from = mek.key.remoteJid
			const type = Object.keys(mek.message)[0]
			const { text, extendedText, contact, location, liveLocation, image, video, sticker, document, audio, product } = MessageType
            const date = new Date().toLocaleDateString()
			const time = moment.tz('America/Sao_Paulo').format('HH:mm:ss')
			const jam = moment.tz('America/Sao_Paulo').format('HH:mm')
			body = (type === 'conversation' && mek.message.conversation.startsWith(prefix)) ? mek.message.conversation : (type == 'imageMessage') && mek.message.imageMessage.caption.startsWith(prefix) ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption.startsWith(prefix) ? mek.message.videoMessage.caption : (type == 'extendedTextMessage') && mek.message.extendedTextMessage.text.startsWith(prefix) ? mek.message.extendedTextMessage.text : ''
			budy = (type === 'conversation') ? mek.message.conversation : (type === 'extendedTextMessage') ? mek.message.extendedTextMessage.text : ''
	const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
	const args = body.trim().split(/ +/).slice(1)
	const isCmd = body.startsWith(prefix)
 const is = budy.slice(0).trim().split(/ +/).shift().toLowerCase()
			mess = {
  wait: '*「 AGUARDE 」 ⏳*',
  success: '*✔️* Feito',
  Public: '*🚫* Comomado em modo privado agora apenas o proprietário pode usar o bot',
  ferr: 'vixi parece que falhou, tente novamente em brave',
  limitend: 'Desculpe, seu limite acabou, por favor, faça uma compra Dnv.',
  error: {
  stick: '*🚫* Por favor, tente novamente mais tarde',
  Iv: '*🚫* Erro de link'
  },
  only: {
    group: ' [❗] Este comando só pode ser usado em grupos!'
    ownerB: '[❗] Este comando só pode ser usado pelo Dono do Bot',
    admin: '[❗] Este comando só pode ser usado por administradores de grupo!',
    Badmin: ' [❗] Este comando só pode ser usado quando o bot se torna administrador!',
    daftarB: `Oi digite *${prefix}verify* para começar a usar o bot`
  }
}
      const totalchat = await Lxa.chats.all()
			const botNumber = Lxa.user.jid
			const ownerNumber = [`${up.ownerNumber}@s.whatsapp.net`] // substitua isso pelo seu número
			const isGroup = from.endsWith('@g.us')
			const sender = isGroup ? mek.participant : mek.key.remoteJid
			const groupMetadata = isGroup ? await Lxa.groupMetadata(from) : ''
			const groupName = isGroup ? groupMetadata.subject : ''
			const groupId = isGroup ? groupMetadata.jid : ''
			const groupMembers = isGroup ? groupMetadata.participants : ''
			const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
			const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
			const isGroupAdmins = groupAdmins.includes(sender) || false
			const isWelkom = isGroup ? welkom.includes(from) : false
			const isOwner = ownerNumber.includes(sender)
			const isSimi = isGroup ? samih.includes(from): false
      const isRegister = checkRegisteredUser(sender)
			   const sendImage = (teks) => {
		    Lxa.sendMessage(from, teks, image, {quoted:mek})}
      const q = args.join(' ')
      const tescuk = ["0@s.whatsapp.net"]
			let pushname = Lxa.contacts[sender] != undefined ? Lxa.contacts[sender].vname || Lxa.contacts[sender].notify: undefined
			const isUrl = (url) => {
			    return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
			}
			
//--Balasan bot
			const reply = (teks) => {
				Lxa.sendMessage(from, teks, text, {quoted:mek})
			}
			const sendMess = (hehe, teks) => {
				Lxa.sendMessage(hehe, teks, text)
			}
			const mentions = (teks, memberr, id) => {
				(id == null || id == undefined || id == false) ? Lxa.sendMessage(from, teks.trim(), extendedText, {contextInfo: {"mentionedJid": memberr}}) : Lxa.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": memberr}})
			}
			const costum = (pesan, tipe, target, target2) => {
      Lxa.sendMessage(from, pesan, tipe, {quoted: {key: {fromMe: false, participant: `${target}`, ...(from ? {
  remoteJid: from
}: {})
  }, message: {
conversation: `${target2}`
  }}})
}
const sendPtt = (teks) => {
  Lxa.sendMessage(from, audio, mp3, {
quoted: mek
  })
}
//--MessageType
			const isMedia = (type === 'imageMessage' || type === 'videoMessage')
			const isQuotedText = type === 'extendedTextMessage' && content.includes('textMessage')
const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')

//--Colors
      colors = ['red','white','black','blue','yellow','green']

//--Console log grup
			if (!isGroup && isCmd) console.log('\x1b[1;37m>', time, color(command), 'from', color(pushname), 'args :', (args.length))
			
//--Console log chat pribadi
			if (isCmd && isGroup) console.log('\x1b[1;37m>', time, color(command), 'from', (groupName), 'args :', color(args.length))

//---Metadata stiker
	    let authorname = Lxa.contacts[from] != undefined ? Lxa.contacts[from].vname || Lxa.contacts[from].notify : undefined	
	    if (authorname != undefined) { } else { authorname = groupName }				function addMetadata(packname, author) {	

				if (!packname) packname = 'Lexa Bot'; if (!author) author = 'ID';	
				author = author.replace(/[^a-zA-Z0-9]/g, '');	
				let name = `${author}_${packname}`
				if (fs.existsSync(`./src/stickers/${name}.exif`)) return `./src/stickers/${name}.exif`
				const json = {	
					"sticker-pack-name": packname,
					"sticker-pack-publisher": author,
				}
				const littleEndian = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00])	
				const bytes = [0x00, 0x00, 0x16, 0x00, 0x00, 0x00]	

				let len = JSON.stringify(json).length	
				let last	

				if (len > 256) {	
					len = len - 256	
					bytes.unshift(0x01)	
				} else {	
					bytes.unshift(0x00)	
				}	

				if (len < 16) {	
					last = len.toString(16)	
					last = "0" + len	
				} else {	
					last = len.toString(16)	
				}	

				const buf2 = Buffer.from(last, "hex")	
				const buf3 = Buffer.from(bytes)	
				const buf4 = Buffer.from(JSON.stringify(json))	

				const buffer = Buffer.concat([littleEndian, buf2, buf3, buf4])	

				fs.writeFile(`./src/stickers/${name}.exif`, buffer, (err) => {	
					return `./src/stickers/${name}.exif`	
				})	

			}

//----limit
const isLimit = (sender) => {
  let position = false
  for (let i of _limit) {
if (i.id === sender) {
  let limits = i.limit
  if (limits >= limitawal) {
position = true
return true
  } else {
_limit
position = true
return false
  }
}
  }
  if (position === false) {
const obj = {
  id: sender,
  limit: 1
}
_limit.push(obj)
fs.writeFileSync('./datauser/limit.json', JSON.stringify(_limit))
return false
  }
}

//--check limit user
const checkLimit = (sender) => {
      let found = false
     for (let lmt of _limit) {
     if (lmt.id === sender) {
      limitCounts = limitawal - lmt.limit
     if (limitCounts <= 0) return Lxa.sendMessage(from, `Maaf limit kamu telah habis, silahkan lakukan pembelian ulang`, text,{ quoted: mek})
      Lxa.sendMessage(from, `〘  *Limit* 〙
Sisa limit anda : *${limitCounts}*
_Penggunaan limit hanya pada fitur-fitur tertentu_`, text, { quoted : mek})
      found = true
                                }
                        }
      if (found === false) {
      let obj = { id: sender, limit: 1 }
      _limit.push(obj)
     fs.writeFileSync('./datauser/limit.json', JSON.stringify(_limit))
     Lxa.sendMessage(from, `〘  *Limit* 〙
Seu limite restante : *${limitCounts}*
_O uso de limites é apenas em alguns comando_`, text, { quoted : mek})
                        }
                }

//--Balance
if (isRegister && isGroup) {
  const checkATM = checkATMuser(sender)
  try {
if (checkATM === undefined) addATM(sender)
const uangsaku = Math.floor(Math.random() * 10) + 90
addKoinUser(sender, uangsaku)
  } catch (err) {
console.error(err)
  }
}


//--Member limit
if (isGroup) {
  try {
const getmemex = groupMembers.length
if (getmemex <= memberlimit) {
  Lxa.sendMessage(from, `Desculpe, os requisitos de membro devem estar acima de ${memberlimit}, Entao vou ter que te expulsar 👋🏻`, text)

  setTimeout(() => {
Lxa.groupLeave(from) // ur cods
  }, 5000) // 1000 = 1s,
}
  } catch {
console.error(err)
  }
}


//--Other Function
const apakah = ['Ya',
  'Tidak',
  'Mungkin']
const bisakah = ['Bisa',
  'Tidak Bisa',
  'Mungkin']
const kapankah = ['Hari Lagi',
  'Minggu Lagi',
  'Bulan Lagi',
  'Tahun Lagi']



//--Auto respon
if(budy.match('lexa')){
result = fs.readFileSync(`./temp/stick/emm.webp`)
  Lxa.sendMessage(from, result, sticker, {
quoted: mek
  })
}
//--End auto respon 1

//--Auto respon 2
switch(is) {
  case 'bot':
  case 'hai':
  case 'Bot':
  case 'bro':
buf = fs.readFileSync(`./temp/audio/onichan.mp3`)
Lxa.sendMessage(from, buf, audio, {
  mimetype: 'audio/mp4', quoted: mek, ptt: true
})
break

case '-menu':
case '.help':
case '!help':
case '!menu':
case '/menu':
case '/help':
case 'help':
case 'menu':
hasil = `        ────────────────
Oii *${pushname}* tente digitar ${prefix}menu
        ────────────────`
reply(hasil)
        break
}

			switch(command) {
case 'help':
  case 'menu':
case '?':
  if (!isRegister) return reply(mess.only.daftarB)
  const uangku = checkATMuser(sender)
  uptime = process.uptime()
  const Menu = {
text: `    ────✪ 🄼🅁🄵.🅉🅅🅇 ✪────
        ────────────────
〘 *USER* 〙
‣ Nome : *${pushname}*
‣ Numero: *${sender.split("@")[0]}*

〘 *BOT* 〙
‣ Prefix:  *「 ${prefix} 」*
‣ Nome: * Lexa V.2*
‣ WAConnection: *Baileys*
‣ Status online: *${kyun(uptime)}*
‣ Estado: *ON*
‣ Grupo:  *${groupName}*

*Dono do BOT*
wa.me/558287515844
┏━━━━━━━━━━━━━━━━━━━━
┃─────〘 *I'm Lexa V.2* 〙────
┃━━━━━━━━━━━━━━━━━━━━
┠❍ *${prefix}Simi (Teks)*
┠❍ *${prefix}Info*
┠❍ *${prefix}Owner*
┠❍ *${prefix}Donasi*
┠❍ *${prefix}Ping*
┗━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━━━━━━━━━━━━━━
┃─────〘  *LISTA DE COMANDOS* 〙─────
┗━━━━━━━━━━━━━━━━━━━━
*〘 GRUPO 〙*
┏━━━━━━━━━━━━━━━━━━━━
┠❍ *${prefix}Listadmin*
┠❍ *${prefix}Listonline*
┠❍ *${prefix}Closegc*
┠❍ *${prefix}Opengc*
┠❍ *${prefix}Promote*
┠❍ *${prefix}Demote*
┠❍ *${prefix}Setname*
┠❍ *${prefix}Setdesk*
┠❍ *${prefix}Add*
┠❍ *${prefix}Kick*
┠❍ *${prefix}Tagall*
┠❍ *${prefix}Linkgc*
┠❍ *${prefix}Leave*
┠❍ *${prefix}Notif*
┠❍ *${prefix}Welcome*
┠❍ *${prefix}Delete (Reply pesan)*
┗━━━━━━━━━━━━━━━━━━━━
*〘 EDITANDO 〙*
┏━━━━━━━━━━━━━━━━━━━━
┠❍ *${prefix}Gtav (Foto)*
┠❍ *${prefix}Wanted (Foto)*
┠❍ *${prefix}Drawing (Foto)*
┗━━━━━━━━━━━━━━━━━━━━
*〘 ANIME 〙*
┏━━━━━━━━━━━━━━━━━━━━
┠❍ *${prefix}Kusonime (Query)*
┠❍ *${prefix}Neonime (Query)*
┠❍ *${prefix}personagem (Query)*
┠❍ *${prefix}Wait*
┠❍ *${prefix}wanime*
┠❍ *${prefix}Loli*
┠❍ *${prefix}Loli2*
┠❍ *${prefix}Neko*
┗━━━━━━━━━━━━━━━━━━━━
*〘 TOOLS 〙*
┏━━━━━━━━━━━━━━━━━━━━
┠❍ *${prefix}Stiker*
┠❍ *${prefix}Triggered*
┠❍ *${prefix}Wasted*
┠❍ *${prefix}Ttp (Texto)*
┠❍ *${prefix}Toimg*
┠❍ *${prefix}Tomp3*
┠❍ *${prefix}Play (Texto)*
┠❍ *${prefix}Tts (Texto)*
┠❍ *${prefix}Igstalk (username)*
┠❍ *${prefix}Wame*
┠❍ *${prefix}Nulis (Texto)*
┠❍ *${prefix}Gplaystore*
┗━━━━━━━━━━━━━━━━━━━━
*〘 PICTURE 〙*
┏━━━━━━━━━━━━━━━━━━━━
┠❍ *${prefix}Meme*
┠❍ *${prefix}Quotes*
┠❍ *${prefix}Cyberpunk*
┠❍ *${prefix}Img (Query)*
┠❍ *${prefix}Google (Query)*
┗━━━━━━━━━━━━━━━━━━━━
*〘 download 〙*
┏━━━━━━━━━━━━━━━━━━━━
┠❍ *${prefix}Ytmp3 (Link)*
┠❍ *${prefix}Ytmp4 (Link)*
┠❍ *${prefix}Fb (Link)*
┠❍ *${prefix}Ig (Link)*
┠❍ *${prefix}Scdl (Link)*
┠❍ *${prefix}Tik (Link)*
┠❍ *${prefix}Pin (Link)*
┠❍ *${prefix}Joox (Judul lagu*)
┗━━━━━━━━━━━━━━━━━━━━
*〘 OWNER 〙*
┏━━━━━━━━━━━━━━━━━━━━
┠❍ *${prefix}Clone*
┠❍ *${prefix}Block*
┠❍ *${prefix}Unblock*
┠❍ *${prefix}Bc*
┠❍ *${prefix}Blocklist*
┗━━━━━━━━━━━━━━━━━━━━`,

contextInfo: {
  mentionedJid: [sender]
}
  }
  Lxa.sendMessage(from, Menu, text, {
quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg", "caption": "Wendel ne kkk❤️", "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=", "fileLength": "28777", "height": 1080, "width": 1079, "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=", "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=", "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69", "mediaKeyTimestamp": "1610993486", "jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABERERESERMVFRMaHBkcGiYjICAjJjoqLSotKjpYN0A3N0A3WE5fTUhNX06MbmJiboyiiIGIosWwsMX46/j///8BERERERIRExUVExocGRwaJiMgICMmOiotKi0qOlg3QDc3QDdYTl9NSE1fToxuYmJujKKIgYiixbCwxfjr+P/////CABEIADoAUQMBIgACEQEDEQH/xAAsAAEAAwEBAQAAAAAAAAAAAAAAAgMFBAYBAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAADwYAAAAAEo2EoeggYctbsPMX7XIZPycABZWNvLoHTfnjTo4x0c4AAAAAAAf//EAC0QAAMAAgEDAwIDCQAAAAAAAAECAwQRAAUSMRMhImGSFCCRJEBBQlBRUmOx/9oACAEBAAE/AP3dFLsqjW2IA2QB+p5PHvUoJxdy7FU7VJ7iPcgcM6AMxRtKwVjrwT4B4Y2Hdub/ABRXb28K2tE/Q74+Nead7yZV+BHcNbDglSPodcKsp0wIOgf14mLeisyKCFAJII/ipf8A4vCrKFJBAYbH1Hj8kXWdFdpJUD+RywB+0g8z8N4dXtiQgHxlo5STuyy2qbbmXTHxhjt2SZ6I4yISuzy/17IZudWImmKoT0bvH9pkHc+DpAQxbma/bTqUE2hwEAlUO/eQjiXMARsnTUvAX/EZxgS7vtUQIAF03OjXcdSxJnbLS0kPzddbPbsFCOUFQQKBge1dBv8AEjY/JJ1m4ZpJQDfwbYB+0g8yOvXybpZ8eHm21AfTesgRuXrOpUpjzj9ELnf3luWyTe+Tek0L2ZmPkBSx3teX6lW4uTKS0v7Wou9v7huY/VDj+l24sG9K5vLff8GOv7NzEy/wl43WEneWivd3a7g2w3sRzKyGybeqyKnwRAq70AihB5/on//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQIBAT8AR//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQMBAT8AR//Z", "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw==" } } } })
  break

//--Cek limit user
case 'ceklimit':
  if (!isRegister) return reply(mess.only.daftarB)
  checkLimit(sender)
  break

//---cek saldo user
case 'ceksaldo':
  if (!isRegister) return reply(mess.only.daftarB)
  uangkau = checkATMuser(sender)
  hasil = `〘  *CARTEIRA* 〙
╔════════════════════
╠≽️ *Nome* : *${pushname}*
╠≽️ *Saldo* : *Rp.${uangkau}.-*
╠≽️ *Número* : *${sender.split("@")[0]}*
╠≽️ *SN* : ${serialUser}
╚════════════════════`
  reply(hasil)
	break
					case 'slow':
					low = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					slo = await Lxa.downloadAndSaveMediaMessage(low)
					ran = getRandom('.mp3')
					exec(`ffmpeg -i ${slo} -filter:a "atempo=0.7,asetrate=44100" ${ran}`, (err, stderr, stdout) => {
						fs.unlinkSync(slo)
						if (err) return reply('Error!')
						hah = fs.readFileSync(ran)
						Lxa.sendMessage(from, hah, audio, {mimetype: 'audio/mp4', ptt:true, quoted: mek})
						fs.unlinkSync(ran)
					})
				break
				case 'tupai':
					pai = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo

					tup = await Lxa.downloadAndSaveMediaMessage(pai)
					ran = getRandom('.mp3')
					exec(`ffmpeg -i ${tup} -filter:a "atempo=0.5,asetrate=65100" ${ran}`, (err, stderr, stdout) => {
						fs.unlinkSync(tup)
						if (err) return reply('Error!')
						hah = fs.readFileSync(ran)
						Lxa.sendMessage(from, hah, audio, {mimetype: 'audio/mp4', ptt:true, quoted: mek})
						fs.unlinkSync(ran)
					})
				break
				case 'gemuk':
					muk = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo

					gem = await Lxa.downloadAndSaveMediaMessage(muk)
					ran = getRandom('.mp3')
					exec(`ffmpeg -i ${gem} -filter:a "atempo=1.6,asetrate=22100" ${ran}`, (err, stderr, stdout) => {
						fs.unlinkSync(gem)
						if (err) return reply('Error!')
						hah = fs.readFileSync(ran)
						Lxa.sendMessage(from, hah, audio, {mimetype: 'audio/mp4', ptt:true, quoted: mek})
						fs.unlinkSync(ran)
					})
				break
				case 'bass':                 
					ass = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo

					bas = await Lxa.downloadAndSaveMediaMessage(ass)
					ran = getRandom('.mp3')
					exec(`ffmpeg -i ${bas} -af equalizer=f=94:width_type=o:width=2:g=30 ${ran}`, (err, stderr, stdout) => {
						fs.unlinkSync(bas)
						if (err) return reply('Error!')
						hah = fs.readFileSync(ran)
						Lxa.sendMessage(from, hah, audio, {mimetype: 'audio/mp4', ptt:true, quoted: mek})
						fs.unlinkSync(ran)
					})
					break

//--Info bot
				case 'info':
  me = Lxa.user
  uptime = process.uptime()
  teks = `*‣ Nome do bot* : ${me.name}
  ‣ *Número do bot* : @${me.jid.split('@')[0]}
  ‣ *Dono* : Wendel ne kkkk
  ‣ *Prefix* : ${prefix}
  ‣ *Total De contatos Bloqueados* : ${blocked.length}
  ‣ *O bot está ativo a* : ${kyun(uptime)}
  ‣ *Total Usuários* : ${_registered.length} User
  ‣ *Total Chat* : ${totalchat.length}`
  buffer = await getBuffer(me.imgUrl)
  Lxa.sendMessage(from, buffer, image, {
caption: teks, contextInfo: {
  mentionedJid: [me.jid]}})
  break

//---Kecepatan respon
case 'ping':
  case 'speed':
if (!isRegister) return reply(mess.only.userB)
const timestamp = speed();
const latensi = speed() - timestamp
Lxa.updatePresence(from, Presence.composing)
uptime = process.uptime()
Lxa.sendMessage(from, `*Velocidade de resposta do bot*\n‣ *Speed* : ${latensi.toFixed(4)} _Second_\n\n*Info bot*\n‣ *Total chat* : ${totalchat.length}\n‣ *Total Usuários* : ${_registered.length}\n‣ *Bloqueados* : ${blocked.length}\n‣ *Online* : ${kyun(uptime)}`, text, {
  quoted: mek
})
break

//---donasi
case 'donasi':
Lxa.updatePresence(from, Presence.composing)
if (!isRegister) return reply(mess.only.daftarB)
hasil = `Ajude a doar para manter o bot funcionando.

Cuidado com o fogo, mesmo que você tenha um pedaço de tâmaras. Aquele que não encontra uma boa palavra
_“afasta-te do fogo do inferno, nem que seja dando esmola (um pouco). Se não tiver, pode ser com a palavra thayyibah "[HR. Bukhari 6539, Muslim 1016]_

*Pulsa :* _${Pulsa}_
*Dana :* _${Dana}_
*OVO :* _${Ovo}_`,
Lxa.sendMessage(from, hasil, text, {
  quoted: mek
})
break

//--o significado do nome
case 'arti':
if (args.length < 1) return reply('Digite o Nome')
Lxa.updatePresence(from, Presence.composing)
if (!isRegister) return reply(mess.only.daftarB)
teks = body.slice(6)
try {
data = await fetchJson(`https://scrap.terhambar.com/nama?n=${teks}`)
hasil = `Nome : *${teks}*\n Significado: ${data.result.arti}`
reply(hasil)
await limitAdd(sender)
} catch {
  reply(mess.ferr)
}
break

//---couple pasangan
case 'couple':
Lxa.updatePresence(from, Presence.composing)
if (!isRegister) return reply(mess.only.daftarB)
if (!q.includes(' & ')) return  reply('O formato do texto está errado, coloque "&" entre os nomes')
const aku = q.substring(0, q.indexOf(' &') - 0)
const kamu = q.substring(q.lastIndexOf('& ') + 1)
try {
data = await fetchJson(`https://arugaz.herokuapp.com/api/jodohku?nama=${aku}&pasangan=${kamu}`, {
  method: 'get'
})
yoi = `‣ *Nome* : ${aku}
‣ *Casal* : ${kamu}
‣ *Positivo* : ${data.positif}
‣ *Negativo* : ${data.negatif}`
Lxa.sendMessage(from, yoi, text, {
  quoted: mek
})
await limitAdd(sender)
} catch {
  reply(mess.ferr)
}
break

//---Zodíaco diário
case 'zodiak':
if (args.length < 1) return reply(' Digite o nome do seu zodíaco')
Lxa.updatePresence(from, Presence.composing)
if (!isRegister) return reply(mess.only.daftarB)
teks = body.slice(8)
try {
data = await fetchJson(`https://api.vhtear.com/zodiak?query=${teks}&apikey=${vKey}`)
hasil = `Zodíaco : *${data.result.zodiak}*\nPrevisão de hoje : *${data.result.ramalan}*\n${data.result.inspirasi}`
reply(hasil)
await limitAdd(sender)
} catch {
  reply(mess.ferr)
}
break

//--procurar pinterest
  case 'img':
if (!isRegister) return reply(mess.only.daftarB)
if (isLimit(sender)) return reply(mess.limitend)
if (args.length < 1) return reply('digite oq quer procurar')
tels = body.slice(5)
Lxa.updatePresence(from, Presence.composing)
reply(mess.wait)
try {
data = await fetchJson(`https://api.fdci.se/sosmed/rep.php?gambar=${tels}`, {
  method: 'get'
})
n = JSON.parse(JSON.stringify(data));
nimek = n[Math.floor(Math.random() * n.length)];
pok = await getBuffer(nimek)
Lxa.sendMessage(from, pok, image, {
  quoted: mek, caption: `Isso foi oq achei de : *${tels}*`
})
await limitAdd(sender)
} catch {
  reply(mess.ferr)
}
break

//--Procurar pinterest
case 'pinterest':
tels = body.slice(11)
if (!isRegister) return reply(mess.only.daftarB)
if (isLimit(sender)) return reply(mess.limitend)
if (args.length < 1) return reply('digite oq quer procurar')
Lxa.updatePresence(from, Presence.composing)
try {
data = await fetchJson(`https://api.fdci.se/sosmed/rep.php?gambar=${tels}`, {
  method: 'get'
})
reply(mess.wait)
n = JSON.parse(JSON.stringify(data));
nimek = n[Math.floor(Math.random() * n.length)];
pok = await getBuffer(nimek)
Lxa.sendMessage(from, pok, image, {
  quoted: mek, caption: `Isso foi oq achei de : *${tels}*`
})
await limitAdd(sender)
} catch {
  reply(mess.ferr)
}
break

case 'listonline':
        		let ido = args && /\d+\-\d+@g.us/.test(args[0]) ? args[0] : from
			    let online = [...Object.keys(Lxa.chats.get(ido).presences), Lxa.user.jid]
			    Lxa.sendMessage(from, 'List Online:\n' + online.map(v => '- @' + v.replace(/@.+/, '')).join`\n`, text, { quoted: mek,
  			  contextInfo: { mentionedJid: online }
			    })
				break



//--pinterest anime neko
case 'neko':
if (!isRegister) return reply(mess.only.daftarB)
if (isLimit(sender)) return reply(mess.limitend)
Lxa.updatePresence(from, Presence.composing)
uk = ["anime neko"]
nk = uk[Math.floor(Math.random() * uk.length)]
try {
data = await fetchJson(`https://api.fdci.se/sosmed/rep.php?gambar=${nk}`, {
  method: 'get'
})
reply(mess.wait)
n = JSON.parse(JSON.stringify(data));
nimek = n[Math.floor(Math.random() * n.length)];
pok = await getBuffer(nimek)
Lxa.sendMessage(from, pok, image, {
  quoted: mek, caption: `neko 😏`
})
await limitAdd(sender)
} catch {
  reply(mess.ferr)
}
break

//--Pinteres anime loli
  case 'loli':
if (!isRegister) return reply(mess.only.daftarB)
if (isLimit(sender)) return reply(mess.limitend)
Lxa.updatePresence(from, Presence.composing)
uk = ["anime loli"]
nk = uk[Math.floor(Math.random() * uk.length)]
try {
data = await fetchJson(`https://api.fdci.se/sosmed/rep.php?gambar=${nk}`, {
  method: 'get'
})
reply(mess.wait)
n = JSON.parse(JSON.stringify(data));
nimek = n[Math.floor(Math.random() * n.length)];
pok = await getBuffer(nimek)
Lxa.sendMessage(from, pok, image, {
  quoted: mek, caption: `Loli 😐`
})
await limitAdd(sender)
} catch {
  reply(mess.ferr)
}
break


//--Pinterest Twitter
  case 'twit':
if (!isRegister) return reply(mess.only.daftarB)
if (isLimit(sender)) return reply(mess.limitend)
Lxa.updatePresence(from, Presence.composing)
tw = ["Twitter lucu Indonesia",
  "Twitter harian",
  "Recehkan Twitter",
  "twit lucu"]
nk = tw[Math.floor(Math.random() * tw.length)]
try {
data = await fetchJson(`https://api.fdci.se/sosmed/rep.php?gambar=${nk}`, {
  method: 'get'
})
reply(mess.wait)
n = JSON.parse(JSON.stringify(data));
nimek = n[Math.floor(Math.random() * n.length)];
pok = await getBuffer(nimek)
Lxa.sendMessage(from, pok, image, {
  quoted: mek
})
await limitAdd(sender)
} catch {
  reply(mess.ferr)
}
break
  //
  case 'wanime':
if (!isRegister) return reply(mess.only.daftarB)
if (isLimit(sender)) return reply(mess.limitend)
Lxa.updatePresence(from, Presence.composing)
am = ["anime tumblr",
  "wallpaper anime hd",
  "anime aestethic",
  "anime hd"]
nk = am[Math.floor(Math.random() * am.length)]
data = await fetchJson(`https://api.fdci.se/sosmed/rep.php?gambar=${nk}`, {
  method: 'get'
})
reply(mess.wait)
n = JSON.parse(JSON.stringify(data));
nimek = n[Math.floor(Math.random() * n.length)];
pok = await getBuffer(nimek)
Lxa.sendMessage(from, pok, image, {
  quoted: mek, caption: `Aqui esta!`
})
await limitAdd(sender)
break

//--Pinterest wallpaper
  case 'wp':
case 'wallpaper':
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  Lxa.updatePresence(from, Presence.composing)
  pw = ["wallpaper aestethic",
"wallpaper tumblr",
"wallpaper lucu",
"wallpaper"]
  nk = pw[Math.floor(Math.random() * pw.length)]
  try {
  data = await fetchJson(`https://api.fdci.se/sosmed/rep.php?gambar=${nk}`, {
method: 'get'
  })
  reply(mess.wait)
  n = JSON.parse(JSON.stringify(data));
  nimek = n[Math.floor(Math.random() * n.length)];
  pok = await getBuffer(nimek)
  Lxa.sendMessage(from, pok, image, {
quoted: mek, caption: `Toma teu wallpaper`
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

//--Pinterest cecan
case 'cecan':
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  tels = body.slice(5)
  Lxa.updatePresence(from, Presence.composing)
  ty = ["ulzhang girl",
"cewek cantik",
"cewe hijab",
"cewe rusia cantik",
"cewe jepang cantik",
"cecan indo"]
  nk = ty[Math.floor(Math.random() * ty.length)]
  try {
  data = await fetchJson(`https://api.fdci.se/sosmed/rep.php?gambar=${nk}`, {
method: 'get'
  })
  reply(mess.wait)
  n = JSON.parse(JSON.stringify(data));
  nimek = n[Math.floor(Math.random() * n.length)];
  pok = await getBuffer(nimek)
  Lxa.sendMessage(from, pok, image, {
quoted: mek, caption: `😎`
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

//--Pinterest citações
case 'quotes':
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  tels = body.slice(5)
  Lxa.updatePresence(from, Presence.composing)
  qt = ["citações",
"citações aestethic brazil"]
  nk = qt[Math.floor(Math.random() * qt.length)]
  try {
  data = await fetchJson(`https://api.fdci.se/sosmed/rep.php?gambar=${nk}`, {
method: 'get'
  })
  reply(mess.wait)
  n = JSON.parse(JSON.stringify(data));
  nimek = n[Math.floor(Math.random() * n.length)];
  pok = await getBuffer(nimek)
  Lxa.sendMessage(from, pok, image, {
quoted: mek, caption: `e isso`
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break



//--Pinterest Cogan
case 'cogan':
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  Lxa.updatePresence(from, Presence.composing)
  uk = ["ulzhang boy","cowok keren","cowo ganteng","cogan","cogan jawa"]
  nk = uk[Math.floor(Math.random() * uk.length)]
  try {
  data = await fetchJson(`https://api.fdci.se/sosmed/rep.php?gambar=${nk}`, {
method: 'get'
  })
  reply(mess.wait)
  n = JSON.parse(JSON.stringify(data));
  nimek = n[Math.floor(Math.random() * n.length)];
  pok = await getBuffer(nimek)
  Lxa.sendMessage(from, pok, image, {
quoted: mek, caption: `Wah ganteng kek gua`
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

//--Pinterest cyberpunk
case 'cyberpunk':
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  Lxa.updatePresence(from, Presence.composing)
  co = ["anime cyberpunk","fotografi cyberpunk","tokyo cyberpunk"]
  nk = co[Math.floor(Math.random() * co.length)]
  try {
  data = await fetchJson(`https://api.fdci.se/sosmed/rep.php?gambar=${nk}`, {
method: 'get'
  })
  reply(mess.wait)
  n = JSON.parse(JSON.stringify(data));
  nimek = n[Math.floor(Math.random() * n.length)];
  pok = await getBuffer(nimek)
  Lxa.sendMessage(from, pok, image, {
quoted: mek
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

case 'jadian':
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  if (args.length < 1) return Lxa.sendMessage(from, `Insira a Dia-mês-ano`, text, {
quoted: mek
  })
  if (!q.includes('-')) return  reply('Insira a dia-mês-ano corretamente\n*Exemplo : 21-05-2002*')
  pc = body.slice(9)
  teks1 = pc.split("-")[0];
  teks2 = pc.split("-")[1];
  teks3 = pc.split("-")[2];
  reply(mess.wait)
  try {
  iya = await fetchJson(`http://lolhuman.herokuapp.com/api/jadian/${teks1}/${teks2}/${teks3}?apikey=${lolKey}`, {
method: 'get'
  })
  hasil = `‣ *Características* : ${iya.result.karakteristik}\n‣ *Descrição* : ${iya.result.deskripsi}`
  Lxa.sendMessage(from, hasil, text, {
quoted: mek
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break


case 'asupan':
  if (isLimit(sender)) return reply(mess.limitend)
if (!isRegister) return reply(mess.only.daftarB)
try {
data = await fetchJson(`https://api.itsmeikyxsec404.xyz/asupan?apikey=${meKey}`)
reply(mess.wait)
hasil = await getBuffer(data.result)
Lxa.sendMessage(from, hasil, video, {
  caption: 'Aqui mano', quoted: mek
})
await limitAdd(sender)
} catch {
  reply(mess.ferr)
}
break

case 'weton':
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  if (args.length < 1) return Lxa.sendMessage(from, `Insira a data-mês-ano`, text, {
quoted: mek
  })
  if (!q.includes('-')) return  reply('Insira a data-mês-ano corretamente\n*Exemplo : 09-09-2009*')
  pc = body.slice(7)
  teks1 = pc.split("-")[0];
  teks2 = pc.split("-")[1];
  teks3 = pc.split("-")[2];
  reply(mess.wait)
  try {
  iya = await fetchJson(`http://lolhuman.herokuapp.com/api/weton/${teks1}/${teks2}/${teks3}?apikey=${lolKey}`, {
method: 'get'
  })
  hasil = `${iya.result.weton}\n\Características: ${iya.result.karakter}\n Profissão : ${iya.result.pekerjaan}\n Fortuna : ${iya.result.rejeki}\nJogo : ${iya.result.jodoh}`
reply(hasil)
break
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

//-- Gay porcentagem
case 'seberapagay':
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  if (args.length < 1) return Lxa.sendMessage(from, 'marque alguém', text, {
quoted: mek
  })
  teks = body.slice(13)
  Lxa.updatePresence(from, Presence.composing)
  data = await fetchJson(`https://arugaz.herokuapp.com/api/howgay`)
  hasil = `*Gay Detectado*\n‣ Alvo : *${args[0]}*\n‣ Percentagem : *${data.persen}%*\n*${data.desc}*`
  reply(hasil)
  await limitAdd(sender)
  break
//-- fim

case 'seberapabucin':
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  if (args.length < 1) return Lxa.sendMessage(from, 'Insira o nome do alvo', text, {
quoted: mek
  })
  teks = body.slice(15)
  try {
  Lxa.updatePresence(from, Presence.composing)
  data = await fetchJson(`https://arugaz.herokuapp.com/api/howbucins`)
  hasil = `*Bucin detectado*\n‣ Alvo : *${args[0]}*\n‣ Percentagem : *${data.persen}%*\n*${data.desc}*`
  reply(hasil)
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

//--searching lirik
case 'lirik':
  if (args.length < 1) return reply('Nome da musica')
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  Lxa.updatePresence(from, Presence.composing)
  tels = body.slice(7)
  try {
  anu = await fetchJson(`http://scrap.terhambar.com/lirik?word=${tels}`, {
method: 'get'
  })
  reply(anu.result.lirik)
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

case 'namae':
  if (args.length < 1) return reply(' Insira o nome')
Lxa.updatePresence(from, Presence.composing)
if (!isRegister) return reply(mess.only.daftarB)
if (isLimit(sender)) return reply(mess.limitend)
teks = body.slice(7) 
try {
data = await fetchJson(`https://api.terhambar.com/ninja?nama=${teks}`)
hasil = `*Seu nome ninja*\n*${data.result.ninja}*`
reply(hasil)
await limitAdd(sender)
} catch {
  reply(mess.ferr)
}
break

case 'alay':
  if (args.length < 1) return reply('Digite o texto')
Lxa.updatePresence(from, Presence.composing)
if (!isRegister) return reply(mess.only.daftarB)
if (isLimit(sender)) return reply(mess.limitend)
teks = body.slice(6)
try {
data = await fetchJson(`https://api.terhambar.com/bpk?kata=${teks}`)
reply(data.text)
await limitAdd(sender)
} catch {
  reply(mess.ferr)
}
break


case 'gplaystore':
Lxa.updatePresence(from, Presence.composing)
if (!isRegister) return reply(mess.only.daftarB)
if (isLimit(sender)) return reply(mess.limitend)
goo = body.slice(12)
try {
data = await fetchJson(`https://api.zeks.xyz/api/sgplay?apikey=${viKey}&q=${goo}`, {
method: 'get'
  })

teks = '*Google Play Store*\n\n'
				for (let i of data.result) {
					teks += `        ────────────────\n\n‣ *Nome* : ${i.title}\n‣ *Desenvolvedor* : ${i.developer}\n‣ *Avaliação* : ${i.rating}\n‣ *Link* : ${i.url}\n\n`
				}
				teks += `        ────────────────`
reply(teks.trim())
await limitAdd(sender)
} catch {
  reply(mess.ferr)
}

break
case 'bijak':
Lxa.updatePresence(from, Presence.composing)
if (!isRegister) return reply(mess.only.daftarB)
if (isLimit(sender)) return reply(mess.limitend)
try {
data = await fetchJson(`http://lolhuman.herokuapp.com/api/random/katabijak?apikey=${lolKey}`)
reply(data.result)
await limitAdd(sender)
} catch {
  reply(mess.ferr)
}
break

case 'pantun':
Lxa.updatePresence(from, Presence.composing)
if (!isRegister) return reply(mess.only.daftarB)
if (isLimit(sender)) return reply(mess.limitend)
try {
data = await fetchJson(`http://lolhuman.herokuapp.com/api/random/pantun?apikey=${lolKey}`)
reply(data.result)
await limitAdd(sender)
} catch {
  reply(mess.ferr)
}
break

case 'bucin':
case 'gombal':
  Lxa.updatePresence(from, Presence.composing)
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  try {
  data = await fetchJson(`http://lolhuman.herokuapp.com/api/random/bucin?apikey=${lolKey}`)
  reply(data.result)
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

case 'personagem':
  teks = body.slice(10)
  Lxa.updatePresence(from, Presence.composing)
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  if (args.length < 1) return reply('Digite o nome do personagem de anime')
  try {
  data = await fetchJson(`http://lolhuman.herokuapp.com/api/character?apikey=${lolKey}&query=${teks}`)
  buf = await getBuffer(data.result.image.large)
  hasil = `‣ *Nome* : ${data.result.name.full} *(${data.result.name.native})*\n‣ *Descrição* : ${data.result.description}`
  Lxa.sendMessage(from, buf, image, {
caption: hasil, quoted: mek
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

case 'textgen':
  teks = body.slice(9)
  if (args.length < 1) return reply('Digite o texto')
  Lxa.updatePresence(from, Presence.composing)
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  try {
  data = await fetchJson(`https://api.arugaz.my.id/api/random/text/fancytext?text=${teks}`)
  reply(data.result)
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break


case 'anime':
  teks = body.slice(6)
  Lxa.updatePresence(from, Presence.composing)
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  if (args.length < 1) return reply('Digite o nome do anime')
  try {
  data = await fetchJson(`https://st4rz.herokuapp.com/api/kuso?q=${teks}`)
  hasil = `‣ *Título* : ${data.title}\n‣ *Info* : ${data.info}\n‣ *Sinopse* : ${data.sinopsis}\n‣ *Link download* :\n${data.link_dl}`
  buf = await getBuffer(data.thumb)
  Lxa.sendMessage(from, buf, image, {
quoted: mek, caption: hasil
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

case 'igstalk':
yolo = body.slice(9)
if (!isRegister) return reply(mess.only.daftarB)
if (isLimit(sender)) return reply(mess.limitend)
if (args.length < 1) return reply('Insira nome de usuário')
try {
hmm = await fetchJson(`http://lolhuman.herokuapp.com/api/stalkig/${yolo}?apikey=${lolKey}`)
reply(mess.wait)
buffer = await getBuffer(hmm.result.photo_profile)
hasil = `‣ *Username* : ${hmm.result.username}\n‣ *Nome completo* : ${hmm.result.fullname}\n‣ *Seguidores* : ${hmm.result.followers}\n‣ *Seguindo* : ${hmm.result.following}\n‣ *Bio* : ${hmm.result.bio}\n‣ *Link* : https://www.instagram.com/${hmm.result.username}\n‣ Follow : ${Ig}`
Lxa.sendMessage(from, buffer, image, {
  quoted: mek, caption: hasil
})
await limitAdd(sender)
} catch {
  reply(mess.ferr)
}
break


case 'apakah':
  if (args.length < 1) return reply(' Introduzir uma pergunta')
  Lxa.updatePresence(from, Presence.composing)
  random = apakah[Math.floor(Math.random() * (apakah.length))]
  hasil = `o que : *${body.slice(8)}*\n\nResposta : *${random}*`
  reply(hasil)
  break

//bisakah
case 'bisakah':
  if (args.length < 1) return reply('introduzir uma pergunta')
  Lxa.updatePresence(from, Presence.composing)
  if (!isRegister) return reply(mess.only.daftarB)
  random = bisakah[Math.floor(Math.random() * (bisakah.length))]
  hasil = `pode : *${body.slice(9)}*\n\nResposta : *${random}*`
  reply(hasil)
  break

case 'rate':
  if (args.length < 1) return reply(' Introduzir uma pergunta')
  Lxa.updatePresence(from, Presence.composing)
  if (!isRegister) return reply(mess.only.daftarB)
  random = `${Math.floor(Math.random() * 100)}`
  hasil = `Avaliação : *${body.slice(6)}*\n\nResposta : *${random}%*`
  reply(hasil)
  break

case 'kapankah':
  if (args.length < 1) return reply('Introduzir uma pergunta')
  Lxa.updatePresence(from, Presence.composing)
  if (!isRegister) return reply(mess.only.daftarB)
  random = kapankah[Math.floor(Math.random() * (kapankah.length))]
  random2 = `${Math.floor(Math.random() * 8)}`
  hasil = `Quando você vai : *${body.slice(10)}*\n\nResposta : *${random2} ${random}*`
  reply(hasil)
  break

case 'kapan':
  if (args.length < 1) return reply('Introduzir uma pergunta')
  Lxa.updatePresence(from, Presence.composing)
  if (!isRegister) return reply(mess.only.daftarB)
  random = kapankah[Math.floor(Math.random() * (kapankah.length))]
  random2 = `${Math.floor(Math.random() * 8)}`
  hasil = `Quando você vai : *${body.slice(7)}*\n\nResposta : *${random2} ${random}*`
  reply(hasil)
  break

case 'setppgc':
if (!isGroup) return reply(mess.only.group)
if (!isRegister) return reply(mess.only.daftarB)
if (!isGroupAdmins) return reply(mess.only.admin)
if (!isBotGroupAdmins) return reply(mess.only.Badmin)
const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: mek
reply(mess.wait)
const media = await Lxa.downloadAndSaveMediaMessage(encmedia)
await Lxa.updateProfilePicture (from, media)
reply('FT do grupo alterada')
break

case 'triggered':
					case 'ger':
 if (!isRegister) return reply(mess.only.userB)
            var imgbb = require('imgbb-uploader')
           if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
           ger = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
           reply(mess.wait)
         owgi = await Lxa.downloadAndSaveMediaMessage(ger)
           anu = await imgbb("08579d070df9a07cb1c2ee565aece767", owgi)
        teks = `${anu.display_url}`
         ranp = getRandom('.gif')
        rano = getRandom('.webp')
        anu1 = `https://some-random-api.ml/canvas/triggered?avatar=${teks}`
       exec(`wget ${anu1} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
                                                fs.unlinkSync(ranp)
                                                if (err) return reply(mess.error.stick)
                                                nobg = fs.readFileSync(rano)
                                                Lxa.sendMessage(from, nobg, sticker, {quoted: mek})
                                                fs.unlinkSync(rano)
                                        })
                                    
                                             } else {
                                                 reply('Gunakan foto!')
                                          }
                                             break


case 'tourl':
 if (!isRegister) return reply(mess.only.userB)
            var imgbb = require('imgbb-uploader')
           if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
           ger = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
           reply(mess.wait)
         owgi = await Lxa.downloadAndSaveMediaMessage(ger)
           anu = await imgbb("08579d070df9a07cb1c2ee565aece767", owgi)
        teks = `${anu.display_url}`
reply(teks)
}
break

//---stiker wasted
case 'wasted':
  case 'was':
if (!isRegister) return reply(mess.only.userB)
var imgbb = require('imgbb-uploader')
if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
  ger = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: mek
  reply(mess.wait)
  owgi = await Lxa.downloadAndSaveMediaMessage(ger)
  anu = await imgbb("08579d070df9a07cb1c2ee565aece767", owgi)
  teks = `${anu.display_url}`
  ranp = getRandom('.gif')
  rano = getRandom('.webp')
  anu1 = `https://some-random-api.ml/canvas/wasted?avatar=${teks}`
  exec(`wget ${anu1} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
fs.unlinkSync(ranp)
if (err) return reply(mess.error.stick)
nobg = fs.readFileSync(rano)
Lxa.sendMessage(from, nobg, sticker, {
  quoted: mek
})
fs.unlinkSync(rano)
  })

} else {
  reply('Use uma foto!')
}
break

case 'drawing':
if (!isRegister) return reply(mess.only.userB)
var imgbb = require('imgbb-uploader')
if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
  ted = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: mek
  reply(mess.wait)
  owgi = await Lxa.downloadAndSaveMediaMessage(ted)
  tels = body.slice(7)
  anu = await imgbb("08579d070df9a07cb1c2ee565aece767", owgi)
  hehe = await getBuffer(`https://videfikri.com/api/textmaker/pencil/?urlgbr=${anu.display_url}`)
 Lxa.sendMessage(from, hehe, image, {quoted:mek})
} else {
  reply('Não adicione nada ao comando')
}
break


case 'wanted':
if (!isRegister) return reply(mess.only.userB)
var imgbb = require('imgbb-uploader')
if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
  ted = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: mek
  reply(mess.wait)
  owgi = await Lxa.downloadAndSaveMediaMessage(ted)
  tels = body.slice(7)
  anu = await imgbb("08579d070df9a07cb1c2ee565aece767", owgi)
  hehe = await getBuffer(`https://videfikri.com/api/textmaker/wanted/?urlgbr=${anu.display_url}&text1=Dicari&text2=${tels}`)
 Lxa.sendMessage(from, hehe, image, {quoted:mek})
} else {
  reply('Não adicione nada ao comando')
}
break
   case 'next':
if (!isGroup) return reply(mess.only.group)
  anug = getRegisteredRandomId(_registered).replace('@s.whatsapp.net','')
  await reply('À procura de um parceiro >_<')
  await reply(`wa.me/${anug}`)
  await reply( `Par encontrado: 🐊\n*${prefix}next* — Encontre uma nova correspondência`)
  break
case 'gtav':
if (!isRegister) return reply(mess.only.userB)
var imgbb = require('imgbb-uploader')
if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
  ted = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: mek
  reply(mess.wait)
  owgi = await Lxa.downloadAndSaveMediaMessage(ted)
  tels = body.slice(7)
  anu = await imgbb("08579d070df9a07cb1c2ee565aece767", owgi)
  hehe = await getBuffer(`https://videfikri.com/api/textmaker/gtavposter/?urlgbr=${anu.display_url}`)
 Lxa.sendMessage(from, hehe, image, {quoted:mek})
} else {
  reply('Não adicione nada ao comando')
}
break

//--list kodebahasa
case 'kodebahasa':
Lxa.sendMessage(from, bahasa(prefix, sender), text, {
  quoted: mek
})
break

//--list kode negara
case 'kodenegara':
Lxa.sendMessage(from, negara(prefix, sender), text, {
  quoted: mek
})
					break
//--link wame
case 'wa.me':
case 'wame':
  Lxa.updatePresence(from, Presence.composing)
  options = {
text: `Link WhatsApp : *wa.me/${sender.split("@s.whatsapp.net")[0]}*\n*Ou *\n*api.whatsapp.com/send?phone=${sender.split("@")[0]}*`,
contextInfo: {
  mentionedJid: [sender]
}
  }
  Lxa.sendMessage(from, options, text, {
quoted: mek
  })
  break

//---citado foda-se minha vida
case 'fml':
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  try {
data = await fetchJson(`https://api.zeks.xyz/api/fml`)
if (!isRegister) return reply(mess.only.daftarB)
hasil = data.result
reply(hasil)
await limitAdd(sender)
} catch {
  reply(mess.ferr)
}
break

//--translate semua bahasa
  case 'tl':
    if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
if (args.length < 1) return Lxa.sendMessage(from, ' Insira o texto / código do idioma', text, {
  quoted: mek
})
var pc = body.slice(4)
nomor = pc.split("/")[0];
pesan = pc.split("/")[1];
try {
data = await fetchJson(`https://api-translate.azharimm.tk/translate?engine=google&text=${nomor}&to=${pesan}`)
if (!isRegister) return reply(mess.only.daftarB)
hasil = `*Traduzir* :\n${data.data.result}`
reply(hasil)
await limitAdd(sender)
} catch {
  reply(mess.ferr)
}
break

//---membalikan kalimat
  case 'reverse':
    if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
if (args.length < 1) return Lxa.sendMessage(from, 'Digite o texto', text, {
  quoted: mek
})
var pc = body.slice(9)
try {
data = await fetchJson(`https://videfikri.com/api/hurufterbalik/?query=${pc}`)
if (!isRegister) return reply(mess.only.daftarB)
hasil = data.result.kata
reply(hasil)
await limitAdd(sender)
} catch {
  reply(mess.ferr)
}
break



//--fake reply
case 'fitnah':
if (args.length < 1) return reply(`Usage :\n${prefix}fitnah [@tag|pesan|balasanbot]]\n\nEx : \n${prefix}fitnah @tagmember|hai|hai juga`)
var gh = body.slice(7)
mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
var replace = gh.split("|")[0];
var target = gh.split("|")[1];
var bot = gh.split("|")[2];
Lxa.sendMessage(from, `${bot}`, text, {
  quoted: {
key: {
  fromMe: false, participant: `${mentioned}`, ...(from ? {
remoteJid: from
  }: {})
}, message: {
  conversation: `${target}`
}}})
break

//--Kejujuran
case 'truth':
if (!isRegister) return reply(mess.only.daftarB)
					anu = await fetchJson(`https://xptnbotapinew.herokuapp.com/?truth&apikey=xptn`, {method: 'get'})
					ttrth = `${anu.Dare}`
					truteh = await getBuffer(`https://i.ibb.co/305yt26/bf84f20635dedd5dde31e7e5b6983ae9.jpg`)
					Lxa.sendMessage(from, truteh, image, { caption: '*Verdade*\n\n'+ ttrth, quoted: mek })
await limitAdd(sender)
break

//---Tantangan
  case 'dare':
  if (isLimit(sender)) return reply(mess.limitend)
  if (!isRegister) return reply(mess.only.daftarB)
					anu = await fetchJson(`https://xptnbotapinew.herokuapp.com/?dare&apikey=xptn`, {method: 'get'})
					der = `${anu.Dare}`
					tod = await getBuffer(`https://i.ibb.co/305yt26/bf84f20635dedd5dde31e7e5b6983ae9.jpg`)
					Lxa.sendMessage(from, tod, image, { quoted: mek, caption: '*Dare*\n\n'+ der })
await limitAdd(sender)
break


//--notificação grup
  case 'notif"':

if (!isGroupAdmins) return reply(mess.only.admin)
Lxa.updatePresence(from, Presence.composing)
if (!isRegister) return reply(mess.only.daftarB)
if (!isGroup) return reply(mess.only.group)
teks = `Notificacao @${sender.split("@")[0]}\n*Mensagem : ${body.slice(7)}*`
group = await Lxa.groupMetadata(from);
member = group['participants']
jids = [];
member.map(async adm => {
  jids.push(adm.id.replace('c.us', 's.whatsapp.net'));
})
options = {
  text: teks,
  contextInfo: {
mentionedJid: jids
  },
  quoted: mek
}
await Lxa.sendMessage(from, options, text)
break

  //pencarian wiki
  case 'wiki':
    if (!isRegister) return reply(mess.only.daftarB)
if (isLimit(sender)) return reply(mess.limitend)
if (args.length < 1) return reply('Insira uma consulta')
tels = body.slice(6)
try {
anu = await fetchJson(`https://tobz-api.herokuapp.com/api/wiki?q=${tels}&apikey=BotWeA`, {
  method: 'get'
})
reply(anu.result)
await limitAdd(sender)
} catch {
  reply(mess.ferr)
}
break


//--Goolge Image

case 'google':
  if (!isRegister) return reply(mess.only.daftarB)
if (isLimit(sender)) return reply(mess.limitend)
  if (args.length < 1) return reply('Digite o texto')
  goo = body.slice(7)
  try {
  pint = await getBuffer(`http://lolhuman.herokuapp.com/api/gimage?apikey=${lolKey}&query=${goo}`, {
method: 'get'
  })
  Lxa.updatePresence(from, Presence.composing)
  reply(mess.wait)
  Lxa.sendMessage(from, pint, image, {
caption: '*Google Image*\n\n*Resultado da pesquisa : '+goo+'*', quoted: mek
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break
case 'googleimage':
				   if (args.length < 1) return reply('O que você está procurando?')
					goo = body.slice(7)
					anu = await fetchJson(`https://api.vhtear.com/googleimg?query=${goo}&apikey=dapppbotwa`, {method: 'get'})
					reply(`Harap Sabar Jangan Spam,Jika Ketahuan Spam Banned Balasannya`)
				    var pol = JSON.parse(JSON.stringify(anu.result.result_search));
                    var tes2 =  pol[Math.floor(Math.random() * pol.length)];
					pint = await getBuffer(tes2)
					Lxa.sendMessage(from, pint, image, {caption: '*Resultado : '+goo+'*', quoted: mek })
					break
case 'alay2':
  if (!isRegister) return reply(mess.only.userB)
  if (args.length < 1) return reply(' Digite o texto')
  goo = body.slice(7)
  try { 
  pint = await fetchJson(`http://lolhuman.herokuapp.com/api/upperlower?apikey=${lolKey}&text=${goo}`, {
method: 'get'
  })
  Lxa.updatePresence(from, Presence.composing)
  hasil = pint.result
  Lxa.sendMessage(from, hasil, text, {
quoted: mek
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

//---Neonime search
case 'neonime':
if (!isRegister) return reply(mess.only.daftarB)
if (isLimit(sender)) return reply(mess.limitend)
Lxa.updatePresence(from, Presence.composing)
reply(mess.wait)
if (args.length < 1) return reply(`Insira um título de anime`)
teks = body.slice(9)
try {
data = await fetchJson(`https://api.zeks.xyz/api/neonimesearch?q=${teks}&apikey=${viKey}`, {
  method: 'get'
})
teks = '••••••••••••••••••••••\n'
for (let i of data.result) {
  teks += `‣ *Título* : ${i.title}\n‣ *link* : ${i.link}\n••••••••••••••••••••••\n`
}
reply(teks.trim())
if (data.message) return reply(`Desculpe informação do anime: *${teks} não encontrado`)
await limitAdd(sender)
} catch {
  reply(mess.ferr)
}
break

//---Ganti nama grup
  case 'setname':
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return reply(mess.only.admin)
if (!isBotGroupAdmins) return reply(mess.only.Badmin)
let idgrup = `${from.split("@s.whatsapp.net")[0]}`;
Lxa.groupUpdateSubject(idgrup, `${body.slice(9)}`)
Lxa.sendMessage(from, 'Renomeando o Grupo', text, {
  quoted: mek
})
break

//--ganti desk
  case 'setdesk':
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return reply(mess.only.admin)
if (!isBotGroupAdmins) return reply(mess.only.Badmin)
Lxa.groupUpdateDescription(from, `${body.slice(9)}`)
Lxa.sendMessage(from, 'descrição do grupo alterada', text, {
  quoted: mek
})
					break
//--random meme
case 'meme':
  Lxa.updatePresence(from, Presence.composing)
  if (!isRegister) return reply(mess.only.daftarB)
if (isLimit(sender)) return reply(mess.limitend)
try {
  beh = await fetchJson(`https://api.zeks.xyz/api/memeindo?apikey=${viKey}`)
  pint = await getBuffer(beh.result)
  reply(mess.wait)
  Lxa.sendMessage(from, pint, image, {
quoted: mek
  })
  await limitAdd(sender)
} catch {
  reply(mess.ferr)
}
  break

//--tagme
case 'tagme':
if (!isRegister) return reply(mess.only.daftarB)
const tagme = {
  text: `@${sender.split("@")[0]} é ele`,
  contextInfo: {
mentionedJid: [sender]
  }
}
Lxa.sendMessage(from, tagme, text)
break

case 'kbbi':
  Lxa.updatePresence(from, Presence.composing)
  if (args.length < 1) return reply(`Digite o texto\nExemplo : ${prefix}kbbi humano`)
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  tels = body.slice(6)
  try {
  data = await fetchJson(`https://tobz-api.herokuapp.com/api/kbbi?kata=${tels}&apikey=BotWeA`)
  if (data.error) return reply(data.error)
  hasil = `dicionario\n\n${data.result}`
  reply(hasil)
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break


  case 'chatprank':
Lxa.updatePresence(from, Presence.composing)
if (!isRegister) return reply(mess.only.daftarB)
if (isLimit(sender)) return reply(mess.limitend)
if (args.length < 1) return reply(` Digite o texto\nExemplo : ${prefix}chatprank p/abaixo`)
tels = body.slice(11)
var teks1 = tels.split("/")[0];
var teks2 = tels.split("/")[1];
hasil = `${teks1}͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏${teks2}`
Lxa.sendMessage(from, hasil, text, {
  quoted: mek
})
break

//--searching chord
case 'chord':
  if (args.length < 1) return reply('Insira uma consulta')
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  Lxa.updatePresence(from, Presence.composing)
  tels = body.slice(7)
  try {
  anu = await fetchJson(`https://tobz-api.herokuapp.com/api/chord?q=${tels}&apikey=${tKey}`, {
method: 'get'
  })
  reply(anu.result)
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

//--jadwaltv now
case 'jadwaltvnow':
  if (!isRegister) return reply(mess.only.daftarB)
    if (isLimit(sender)) return reply(mess.limitend)
  Lxa.updatePresence(from, Presence.composing)
  reply(mess.wait)
  try {
  anu = await fetchJson(`http://api-melodicxt-2.herokuapp.com/api/jadwaltvnow?&apiKey=administrator`, {
method: 'get'
  })
  reply(anu.result.jadwalTV)
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

//--jadwaltv ch
case 'jadwaltv':
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  ch = body.slice(10)
  if (args.length < 1) return reply('Digite o nome do canal')
  Lxa.updatePresence(from, Presence.composing)
  reply(mess.wait)
  try {
  anu = await fetchJson(`https://mhankbarbar.tech/api/jdtv?ch=${ch}&apiKey=${BarBarKey}`, {
method: 'get'
  })
  n = JSON.parse(JSON.stringify(anu.result));
  hasil = `*Jadwal Tv* : ${ch} hari ini\n${n}`
  reply(hasil)
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break
          case 'tolol':
  if (!isRegister) return reply(mess.only.daftarB)
  if (!isGroup) return reply(mess.only.group)
					membr = []
					const nus = groupMembers
					const msl = groupMembers
					const siapss = nus[Math.floor(Math.random() * nus.length)]
					const sipss = pushname[Math.floor(Math.random() * msl.length)]
					teks = `*O mais estúpido aqui é :* @${siapss.jid.split('@')[0]}`
					membr.push(siapss.jid)
					mentions(teks, membr, true)
					break
         case 'babi':
  if (!isRegister) return reply(mess.only.daftarB)
  if (!isGroup) return reply(mess.only.group)
					membr = []
					const mes = groupMembers
					const msk = groupMembers
					const siaps = mes[Math.floor(Math.random() * mes.length)]
					const sips = pushname[Math.floor(Math.random() * msk.length)]
					teks = `*A maioria dos porcos aqui está :* @${siaps.jid.split('@')[0]}`
					membr.push(siaps.jid)
					mentions(teks, membr, true)
					break
//--mini map
case 'map':
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  if (args.length < 1) return reply('Insira o nome da área')
  daerah = body.slice(5)
  try {
  data = await fetchJson(`https://mnazria.herokuapp.com/api/maps?search=${daerah}`)
  reply(mess.wait)
  hasil = await getBuffer(data.gambar)
  Lxa.sendMessage(from, hasil, image, {
quoted: mek, caption: `Resultados de *${daerah}*`
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

//--pencarian surah Al-Qur'an
case 'alquran':
  Lxa.updatePresence(from, Presence.composing)
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  if (args.length < 1) return reply(' Digite o número da surata 1-114')
  if (isNaN(args.length < 1)) return await reply('Use um número de surata')
  tels = body.slice(9)
  try {
  data = await fetchJson(`https://api.zeks.xyz/api/quran?no=${tels}&apikey=${viKey}`, {
method: 'get'
  })
  teks = `
  〘  *${data.surah}*  〙
  Adalah surah ke ${data.no} dalam Al-Qur'an dengan jumlah ayat (${data.jumlah_ayat} ayat)
  ──────────────────────

  `
  for (let i of data.ayat) {
teks += `*(${i.number})* ${i.text}\n*(${i.number})* ${i.translation_id}\n••••••••••••••••••••••••••••••••••••••••••••••\n`
  }
  reply(teks.trim())
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

//--História curta
case 'cerpen':
if (!isRegister) return reply(mess.only.daftarB)
Lxa.updatePresence(from, Presence.composing)
if (isLimit(sender)) return reply(mess.limitend)
try {
data = await fetchJson(`https://docs-jojo.herokuapp.com/api/cerpen`)
hasil = `*HISTÓRIA CURTA*\n‣ Título : *${data.result.title}*\n‣ Autor : *${data.result.pengarang}}*\n${data.result.cerpen}`
reply(hasil)
await limitAdd(sender)
} catch {
  reply(mess.ferr)
}
break

//---kontak pemilik bot
case 'owner':
 case 'dono':
if (!isRegister) return reply(mess.only.daftarB)
 client.sendMessage(from, {displayname: "Wendel", vcard: vcard}, MessageType.contact, { quoted: mek})
 client.sendMessage(from, 'Meu dono é esse gasoso aí tal de "Wendel"🙄, chama ele aí ele diz que é "Shitpost"',MessageType.text, { quoted: mek} )
 break


//---Versos aleatórios do Alcorão
case 'ngaji':
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  try {
  anu = await fetchJson(`https://api.banghasan.com/quran/format/json/acak`, {
method: 'get'
  })
  quran = `${anu.acak.ar.teks}\n\n${anu.acak.id.teks}\nQ.S ${anu.surat.nama} ayat ${anu.acak.id.ayat}`
  Lxa.sendMessage(from, quran, text, {
quoted: mek
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

//--tafsir Alquran
case 'tafsir':
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  if (args.length < 1) return reply('Masukan query')
  teks = body.slice(8)
  try {
  Lxa.updatePresence(from, Presence.composing)
  data = await fetchJson(`http://api-melodicxt-2.herokuapp.com/api/tafsir-quran?query=${teks}&apiKey=${Mkey}`)
  hasil = `*${data.result.query}*\n\n${data.result.ayat}\n\n*Terjemahan* :\n${data.result.terjemahan_ayat}\n\n*Tafsir* : ${data.result.tafsir_jalalayn}`
  reply(hasil)
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

//---Jadwal solat
case 'sholat':
  loc = body.slice(7)
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  if (args.length < 1) return reply('Masukan nama daerah')
  try {
  anu = await fetchJson(`https://mhankbarbar.tech/api/jadwalshalat?daerah=${loc}&apiKey=${BarBarKey}`, {
method: 'get'
  })
  mbteks = `*SHALAT*\nDaerah : ${loc}\n‣ *Ashar* : ${anu.Ashar}\n‣ *Dhuha* : ${anu.Dhuha}\n‣ *Dzuhur* : ${anu.Dzuhur}\n‣ *Imsyak* : ${anu.Imsyak}\n‣ *Isya* : ${anu.Isya}\n‣ *Maghrib* : ${anu.Maghrib}\n‣ *Subuh* : ${anu.Subuh}`
  Lxa.sendMessage(from, mbteks, text, {
quoted: mek
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

//--info cuaca
case 'cuaca':
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  if (args.length < 1) return reply('Masukan nama daerah')
  tels = body.slice(7)
  try {
  anu = await fetchJson(`https://freerestapi.herokuapp.com/api/v1/cuaca?p=${tels}`, {
method: 'get'
  })
  hasil = `‣ *Tempat* : ${anu.hasil.Nama}\n‣ *Cuaca* : ${anu.hasil.Cuaca}\n‣ *Angin* : ${anu.hasil.Angin}\n‣ *Suhu* : ${anu.hasil.Suhu}\n‣ *Kelembapan* : ${anu.hasil.Kelembaban}\n‣ *Keterangan* : ${anu.hasil.Keterangan}`
  Lxa.sendMessage(from, hasil, text, {
quoted: mek
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

//--info gempa
//informasi gempa terkini
case 'infogempa':
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  Lxa.updatePresence(from, Presence.composing)
  try {
  anu = await fetchJson(`https://docs-jojo.herokuapp.com/api/infogempa`, {
method: 'get'
  })
  hasil = `‣ *Kedalaman* : ${anu.kedalaman}\n‣ *Koordinat* : ${anu.koordinat}\n‣ *Lokasi* : ${anu.lokasi}\n‣ *Magnitude* : ${anu.magnitude}\n‣ *Potensi* : ${anu.potensi}\n‣ *Waktu* : ${anu.waktu}`
  buffer = await getBuffer(anu.map)
  Lxa.sendMessage(from, buffer, image, {
caption: hasil, quoted: mek
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

//---Buy limit
case 'buylimit':
  if (args.length < 1) return reply(`Berapa limit yang mau di beli? Pastikan saldo ATM cukup juga! \n\nCara cek saldo : ${prefix}Ceksaldo`)
  if (!isRegister) return reply(mess.only.daftarB)
  payout = body.slice(10)
  const koinPerlimit = hargalimit
  const total = koinPerlimit * payout
  if (checkATMuser(sender) <= total) return reply(`Desculpe, você não tem dinheiro suficiente. por favor colete e compre mais tarde`)
  if (checkATMuser(sender) >= total) {
confirmATM(sender, total)
bayarLimit(sender, payout)
await reply(`〘  *NOTA DE PAGAMENTO*  〙\n\n‣ *Remetente* : Admin\n‣ *Receptor* : ${pushname}\n‣ *Compra nominal* : ${body.slice(10)} \n‣ *Limite de preço* : ${koinPerlimit}/limit\n‣ *O saldo remanescente* : ${checkATMuser(sender)}\n\O processo foi bem sucedido com o número do pagamento \n${createSerial(15)}`)
  }
  break

//--transfer
case 'transfer':
  if (!isGroup) return reply(mess.only.group)
  if (!isRegister) return reply(mess.only.daftarB)
  if (args.length < 1) return reply(`Por favor repita com
*${prefix}Transfer Marque o remetente | Quantia de transferência*`)
  if (!q.includes('|')) return  reply('O formato do texto está errado, coloque "|" entre o remetente e o valor')
  const tujuan = q.substring(0, q.indexOf('|') - 1)
  const jumlah = q.substring(q.lastIndexOf('|') + 1)
  if (isNaN(jumlah)) return await reply('Não adicione nenhum sinal !')
  if (jumlah < 5000) return reply(`transferência mínima Rp.5000`)

  if (checkATMuser(sender) <= jumlah) return reply(`Desculpe, você não tem dinheiro suficiente. por favor, colete e transfira novamente mais tarde`)
  if (checkATMuser(sender) >= jumlah) {
const tujuantf = `${tujuan.replace("", '')}@s.whatsapp.net`
fee = 0.005 *  jumlah
hasiltf = jumlah - fee
addKoinUser(tujuantf, hasiltf)
confirmATM(sender, jumlah)
addKoinUser('558287515844@s.whatsapp.net', fee)
await reply(`〘  *TRANSFERÊNCIA*  〙
  A transferência de saldo foi bem sucedida
  ‣ *a partir de* : ${sender.split("@")[0]}
  ‣ *De* : ${tujuan}
  ‣ *Valor da transferência* : Rp.${jumlah},-
  ‣ *taxa de administração* : Rp.${fee},-`)
  }
  await limitAdd(sender)
  break

case 'itsme':
  if (!isRegister) return reply(mess.only.daftarB)
  try {
ppimg = await Lxa.getProfilePicture(`${sender.split('@')[0]}@c.us`)
  } catch {
ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
  }
  teks = `‣ *Nome* : ${pushname}
  ‣ *Número* : ${sender.split("@")[0]}
  ‣ *Link* : wa.me/${sender.split("@")[0]}`
  its = await getBuffer (ppimg)
  Lxa.sendMessage(from, its, image, {
quoted: mek, caption: teks
  })
  await limitAdd(sender)
  break

case 'play':
		if (!isOwner) return reply('Eu nao quero fazer isso')
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  if (args.length < 1) return reply('Digite o título da música')
  reply(mess.wait)
  play = body.slice(6)
  try {
  anu = await fetchJson(`https://api.zeks.xyz/api/ytplaymp3?q=${play}&apikey=apivinz`)
  if (anu.error) return reply(anu.error)
  infomp3 = `*Musica encontrada*\n‣ *Título* : ${anu.result.title}\n‣ *Fonte* : ${anu.result.source}\n‣ *Tamanho* : ${anu.result.size}\n\n_Enviando arquivos aguarde se o áudio não aparecer faça o download aqui_\n‣ *Link* : ${anu.result.url_audio}
  `
  buffer = await getBuffer(anu.result.thumbnail)
  lagu = await getBuffer(anu.result.url_audio)
  Lxa.sendMessage(from, buffer, image, {
quoted: mek, caption: infomp3
  })
  Lxa.sendMessage(from, lagu, audio, {
mimetype: 'audio/mp4', filename: `${anu.result.title}.mp3`, quoted: mek
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break


case 'ytmp3':
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  reply(mess.wait)
  play = body.slice(7)
  if(!isUrl(args[0]) && !args[0].includes('youtu')) return reply('Formato de link incorreto, use link do youtube')
  try {
  anu = await fetchJson(`https://api.zeks.xyz/api/ytmp3/2?url=${play}&apikey=${viKey}`)
  infomp3 = `*Audio Encontrado!!!*\n‣ Título : ${anu.result.title}\n‣ Fonte : ${anu.result.source}\n‣ Tamanho : ${anu.result.size}\n\n_Enviando arquivos por favor aguarde_\n\n_Se o vídeo não aparecer, baixe-o você mesmo usando o link abaixo_\n‣ *link* : ${anu.result.link}`
  buffer = await getBuffer(anu.result.thumb)
  lagu = await getBuffer(anu.result.link)
  Lxa.sendMessage(from, buffer, image, {
quoted: mek, caption: infomp3
  })
  Lxa.sendMessage(from, lagu, audio, {
mimetype: 'audio/mp4', filename: `${anu.result.title}.mp3`, quoted: mek
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

case 'ytmp4':
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  reply(mess.wait)
  play = body.slice(7)
  try {
  anu = await fetchJson(`https://api.zeks.xyz/api/ytmp4?url=${play}&apikey=${viKey}`)
  if(!isUrl(args[0]) && !args[0].includes('youtu')) return reply('Formato de link incorreto, use link do youtube')
  if (anu.error) return reply(anu.error)
  infomp3 = `*Video Encontrado*\n‣ *Título* : ${anu.result.title}\n‣ *Fonte* : ${anu.result.source}\n‣ *Tamanho* : ${anu.result.size}\n\n_Enviando arquivos por favor aguarde_\n\n_Se o vídeo não aparecer, baixe-o você mesmo usando o link abaixo_\n‣ *link* : ${anu.result.url_video}`
  buffer = await getBuffer(anu.result.thumbnail)
  lagu = await getBuffer(anu.result.url_video)
  Lxa.sendMessage(from, buffer, image, {
quoted: mek, caption: infomp3
  })
  Lxa.sendMessage(from, lagu, video, {
mimetype: 'video/mp4', filename: `${anu.result.title}.mp4`, quoted: mek
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break


//---Youtube search
				case 'ytsearch':
					if (args.length < 1) return reply('Insira uma consulta')
					try {
					anu = await fetchJson(`https://mhankbarbar.tech/api/ytsearch?q=${body.slice(10)}&apiKey=${BarBarKey}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					teks = '=================\n'
					for (let i of anu.result) {
						teks += `*Título* : ${i.title}\n*Id* : ${i.id}\n*Publicados* : ${i.publishTime}\n*Duração* : ${i.duration}\n*Views* : ${h2k(i.views)}\n=================\n`
					}
					reply(teks.trim())
					await limitAdd(sender)
					} catch {
					  reply(mess.ferr)
					}
					break

//--download pinterest
case 'pin':
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
    if(!isUrl(args[0]) && !args[0].includes('pin')) return reply('Formato de link incorreto, use o link do pinterest')
  reply(mess.wait)
  play = body.slice(5)
  try {
  anu = await fetchJson(`https://scrap.terhambar.com/pin?url=${play}`)
  if (anu.error) return reply(anu.error)
  n = JSON.parse(JSON.stringify(anu.result.data));
  lagu = await getBuffer(anu.result)
  Lxa.sendMessage(from, lagu, video, {
mimetype: 'video/mp4', filename: `${anu.result}.mp4`, quoted: mek
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

case 'fb':
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  reply(mess.wait)
  if(!isUrl(args[0]) && !args[0].includes('facebook')) return reply('Formato de link incorreto, use link do Facebook')
  play = body.slice(4)
  try {
  anu = await fetchJson(`https://mhankbarbar.tech/api/epbe?url=${play}&apiKey=${BarbarKey}`)
  if (anu.error) return reply(anu.error)
  infomp3 = `*Video Encontrado*\n‣ *Título* : ${anu.title}\n‣ *Publicação* : ${anu.published}\n‣ *Tamanho* : ${anu.filesize}\n\n_Envie arquivos por favor aguarde_\n\n_Se o vídeo não aparecer, baixe-o usando o link abaixo_\n‣ *link* : ${anu.result}`
  lagu = await getBuffer(anu.result)
  Lxa.sendMessage(from, lagu, video, {
mimetype: 'video/mp4', filename: `${anu.result.title}.mp4`, quoted: mek
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

case 'ig':
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  reply(mess.wait)
    if(!isUrl(args[0]) && !args[0].includes('instagram')) return reply('Formato de link incorreto, use link do Instagram')
  play = body.slice(4)
  try {
  anu = await fetchJson(`http://lolhuman.herokuapp.com/api/instagram?apikey=${lolKey}&url=${play}`)
  lagu = await getBuffer(anu.result)
  Lxa.sendMessage(from, lagu, video, {
mimetype: 'video/mp4', filename: `Imlexa.mp4`, quoted: mek
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break
        case 'darkjokes':
  if (!isRegister) return reply(mess.only.daftarB)
				 data = fs.readFileSync('./src/darkjokes.js');
   jsonData = JSON.parse(data);
   randIndex = Math.floor(Math.random() * jsonData.length);
       randKey = jsonData[randIndex];
   hasil = await getBuffer(randKey.result)
      sendImage(hasil, mek, '*DARK BOS: V*')
				break										

//joox download
case 'joox':
					if (!isOwner) return reply('Olha quem é o cachorro')
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
                anu = await fetchJson(`https://tobz-api.herokuapp.com/api/joox?q=${body.slice(6)}&apikey=BotWeA`, {method: 'get'})
               if (anu.error) return reply(anu.error)
                 infomp3 = `「 *JOOX* 」\n\n*• Título* : ${anu.result.judul}\n*• Album* : ${anu.result.album}\n*• Publicados* : ${anu.result.dipublikasi}\n\n*ESPERE ENVIANDO POR FAVOR, NÃO SPAM*`
                bufferddd = await getBuffer(anu.result.thumb)
                 reply(mess.wait)
                buff = await getBuffer(anu.result.mp3)
                Lxa.sendMessage(from, bufferddd, image, {quoted: mek, caption: infomp3})
                Lxa.sendMessage(from, buff, audio, {mimetype: 'audio/mp4', filename: `${anu.result.title}.mp3`, quoted: mek})
  break

case 'scdl':
    if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  if (args.length < 1) return reply('Digite o link do soundcloud')
  tels = body.slice(6)
  try {
  data = await fetchJson(`http://lolhuman.herokuapp.com/api/soundcloud?apikey=${lolKey}&url=${tels}`, {
method: 'get'
  })
  lagu = await getBuffer(data.result)
  Lxa.sendMessage(from, lagu, audio, {
mimetype: 'audio/mp4', filename: `${data.title}.mp3`, quoted: mek
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

case 'tik':
  if (args.length < 1) return reply('insira o link')
  if (!isRegister) return reply(mess.only.daftarB)
  if (isLimit(sender)) return reply(mess.limitend)
  if (!isUrl(args[0]) && !args[0].includes('vt.tiktok')) return reply(mess.error.Iv)
  try {
  anu = await fetchJson(`https://api.arugaz.my.id/api/media/tiktok?url=${args[0]}`, {
method: 'get'
  })
  if (anu.error) return reply(anu.error)
  teks = `*Nome* : ${anu.result.nameInfo}\n*Caption* : ${anu.result.textInfo}\n\n_Enviando arquivos, por favor aguarde_`
  thumb = await getBuffer(anu.result.image)
  Lxa.sendMessage(from, thumb, image, {
quoted: mek, caption: teks
  })
  buffer = await getBuffer(anu.result.mp4direct)
  Lxa.sendMessage(from, buffer, video, {
mimetype: 'video/mp4', filename: `${anu.nameInfo}.mp4`, quoted: mek
  })
  await limitAdd(sender)
  } catch {
    reply(mess.ferr)
  }
  break

/*

				case 'tiktok':
				  case 'tik':
					if (args.length < 1) return reply('Urlnya mana um?')
					if (!isUrl(args[0]) && !args[0].includes('tiktok.com')) return reply(mess.error.Iv)
					reply(mess.wait)
					anu = await fetchJson(`https://mhankbarbar.tech/api/tiktok?url=${args[0]}&apiKey=${BarBarKey}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					buffer = await getBuffer(anu.result)
					Lxa.sendMessage(from, buffer, video, {quoted: mek})
					break
*/

//--block user
				case 'blocklist':
					teks = 'Esta é a lista de números bloqueados :\n'
					for (let block of blocked) {
						teks += `~> @${block.split('@')[0]}\n`
					}
					teks += `Total : ${blocked.length}`
					Lxa.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": blocked}})
					break

//--read text on image
				case 'ocr':
					if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await Lxa.downloadAndSaveMediaMessage(encmedia)
						reply(mess.wait)
						await recognize(media, {lang: 'eng+ind', oem: 1, psm: 3})
							.then(teks => {
								reply(teks.trim())
								fs.unlinkSync(media)
							})
							.catch(err => {
								reply(err.message)
								fs.unlinkSync(media)
							})
					} else {
						reply('Só uma foto mano')
					}
					break

//---textpro
				case 'textpro':
					if (args.length < 1) {
						return reply('Escolha o tema, mn, 1 - 162')
					} else if (args[0].toLowerCase() === 'list') {
						teks = await fetchText('https://mhankbarbar.tech/api/textpro/listtheme')
						teks = teks.replace(/<br>/g, '\n')
						return reply(teks)
					} else if (args.length < 2) {
						return reply('O texto também, mn')
					}
					reply(mess.wait)
					anu = `https://mhankbarbar.tech/api/textpro?pack=${args[0]}&text=${body.slice(1+args[0].length+1)}&apiKey=${BarBarKey}`
					voss = await fetc(anu)	
					ftype = require('file-type')	
					vuss = await ftype.fromStream(voss.body)
					if (vuss !== undefined) {
						Lxa.sendMessage(from, await getBuffer(anu), image, { caption: mess.success, quoted: mek })
					} else {
						reply('Ocorreu um erro, escolha outro tema')
					}
					break

//ephoto
				case 'ephoto':
					if (args.length < 1) {
						return reply('Escolha o tema, mn, 1 - 216')
					} else if (args[0].toLowerCase() === 'list') {
						teks = await fetchText('https://mhankbarbar.tech/api/ephoto/listtheme')
						teks = teks.replace(/<br>/g, '\n')
						return reply(teks)
					} else if (args.length < 2) {
						return reply('O texto também mn ')
					}
					reply(mess.wait)
					anu = `https://mhankbarbar.tech/api/ephoto?pack=${args[0]}&text=${body.slice(2+args[0].length+1)}&apiKey=${BarBarKey}`
					voss = await fetc(anu)
					ftype = require('file-type')
					vuss = await ftype.fromStream(voss.body)
					//console.log(vuss)
					if (vuss !== undefined) {
						Lxa.sendMessage(from, await getBuffer(anu), image, { caption: mess.success, quoted: mek })
					} else {
						reply('Ocorreu um erro, escolha outro tema')
					}
					break

//--harta tahta
				case 'tahta':
  if (!isRegister) return reply(mess.only.daftarB)
   if (isLimit(sender)) return reply(mess.limitend)
                tahta = `${body.slice(7)}`
                     if (args.length < 1) return reply('Cadê o texto, mano??')
                     if (args.length > 10) return reply('pelo menos 10 caracteres')
                     buff = await getBuffer(`https://api.zeks.xyz/api/hartatahta?text=${tahta}&apikey=apivinz`, {method: 'get'})
                     Lxa.sendMessage(from, buff, image, {quoted: mek})
     await limitAdd(sender)
					break
//--stiker maker
					break
				case 'stiker':
				case 'sticker':
				  case 'figu':
      if (isLimit(sender)) return reply(mess.limitend)
	 				if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await Lxa.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						await ffmpeg(`./${media}`)
							.input(media)
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								reply(mess.error.stick)
							})
							.on('end', function () {
								console.log('Finish')
								exec(`webpmux -set exif ${addMetadata('ৡৢ͜͡Wendell', authorname)} ${ran} -o ${ran}`, async (error) => {
									if (error) return reply(mess.error.stick)
									Lxa.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
									fs.unlinkSync(media)	
									fs.unlinkSync(ran)	
								})
								/*Lxa.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
								fs.unlinkSync(media)
								fs.unlinkSync(ran)*/
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					} else if ((isMedia && mek.message.videoMessage.seconds < 11 || isQuotedVideo && mek.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 11) && args.length == 0) {
						const encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await Lxa.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						reply(mess.wait)
						await ffmpeg(`./${media}`)
							.inputFormat(media.split('.')[1])
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								tipe = media.endsWith('.mp4') ? 'video' : 'gif'
								reply(` Gagal, pada saat mengkonversi ${tipe} ke stiker`)
							})
							.on('end', function () {
								console.log('Finish')
								exec(`webpmux -set exif ${addMetadata('ৡৢ͜͡Wendell', authorname)} ${ran} -o ${ran}`, async (error) => {
									if (error) return reply(mess.error.stick)
									Lxa.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
									fs.unlinkSync(media)
									fs.unlinkSync(ran)
								})
								/*Lxa.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
								fs.unlinkSync(media)
								fs.unlinkSync(ran)*/
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					} else if ((isMedia || isQuotedImage) && args[0] == 'nobg') {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await Lxa.downloadAndSaveMediaMessage(encmedia)
						ranw = getRandom('.webp')
						ranp = getRandom('.png')
						reply(mess.wait)
						keyrmbg = 'Your-ApiKey'
						await removeBackgroundFromImageFile({path: media, apiKey: keyrmbg, size: 'auto', type: 'auto', ranp}).then(res => {
							fs.unlinkSync(media)
							let buffer = Buffer.from(res.base64img, 'base64')
							fs.writeFileSync(ranp, buffer, (err) => {
								if (err) return reply('Falha, ocorreu um erro, tente novamente mais tarde.')
							})
							exec(`ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${ranw}`, (err) => {
								fs.unlinkSync(ranp)
								if (err) return reply(mess.error.stick)
								exec(`webpmux -set exif ${addMetadata('ৡৢ͜͡Wendell', authorname)} ${ranw} -o ${ranw}`, async (error) => {
									if (error) return reply(mess.error.stick)
									Lxa.sendMessage(from, fs.readFileSync(ranw), sticker, {quoted: mek})
									fs.unlinkSync(ranw)
								})
								//Lxa.sendMessage(from, fs.readFileSync(ranw), sticker, {quoted: mek})
							})
						})
					/*} else if ((isMedia || isQuotedImage) && colors.includes(args[0])) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await Lxa.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						await ffmpeg(`./${media}`)
							.on('start', function (cmd) {
								console.log('Started :', cmd)
							})
							.on('error', function (err) {
								fs.unlinkSync(media)
								console.log('Error :', err)
							})
							.on('end', function () {
								console.log('Finish')
								fs.unlinkSync(media)
								Lxa.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
								fs.unlinkSync(ran)
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=${args[0]}@0.0, split [a][b]; [a] palettegen=reserve_transparent=off; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)*/
					} else {
						reply(`Envie fotos com legendas ${prefix}sticker ou marque imagem que já foram enviadas`)
					}
     await limitAdd(sender)
					break

//--q temp
			case 'gets':
			  case 'pegars':
				var itsme = `0@s.whatsapp.net`
				var split = `${cr}`
				var selepbot = {
					contextInfo: {
						participant: itsme,
						quotedMessage: {
							extendedTextMessage: {
								text: split,
							}
						}
					}
				}
				namastc = body.slice(6)
				try {
				result = fs.readFileSync(`./temp/stick/${namastc}.webp`)
				Lxa.sendMessage(from, result, sticker, selepbot)
				} catch {
				  reply('Pacote não está registrado')
				}
				break
   case 'getstik':
   case 'pegarfigu':
				var itsme = `0@s.whatsapp.net`
				var split = `${cr}`
				var selepbot = {
					contextInfo: {
						participant: itsme,
						quotedMessage: {
							extendedTextMessage: {
								text: split,
							}
						}
					}
				}
				namastc = body.slice(9)
				try {
				result = fs.readFileSync(`./temp/stick/${namastc}.webp`)
				Lxa.sendMessage(from, result, sticker, selepbot)
				} catch {
				  reply('Pacote não está registrado')
				}
				break
			case 'liststik':
			case 'listafigu':
				teks = '*Lista de Figurinhas :*\n\n'
				for (let awokwkwk of setiker) {
					teks += `- ${awokwkwk}\n`
				}
				teks += `\n*Total : ${setiker.length}*\nUse comandos\n*${prefix}getstik (nome do pacote)*\npegar um adesivo`
				Lxa.sendMessage(from, teks.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": setiker } })
				break
			
			case 'totaluser':
				teks = '*Total Usuario :*\n\n'
				for (let i of _registered) {
					teks += `[${id.toString()}]\`\`\` @${i.split('@')[0]}`
				}
				teks += `\n*Total : ${_registered.length}`
				Lxa.sendMessage(from, teks.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": _registered} })
				break

			case 'addstik':
			case 'addfigu':
				if (!isQuotedSticker) return reply('marque a figurinha')
				if (!isOwner) return reply(mess.only.ownerB)
				svst = body.slice(9)
				if (!svst) return reply('Qual é o nome da figurinha?')
				boij = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
				delb = await Lxa.downloadMediaMessage(boij)
				setiker.push(`${svst}`)
				fs.writeFileSync(`./temp/stick/${svst}.webp`, delb)
				fs.writeFileSync('./temp/stik.json', JSON.stringify(setiker))
				Lxa.sendMessage(from, `Sukses Menambahkan Sticker\nCek dengan cara ${prefix}liststik`, MessageType.text, { quoted: mek })
				break

			case 'addvn':
				if (!isQuotedAudio) return reply('marque o áudio')
				if (!isOwner) return reply(mess.only.ownerB)
				svst = body.slice(7)
				if (!svst) return reply('Qual é o nome do áudio')
				boij = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
				delb = await Lxa.downloadMediaMessage(boij)
				audionye.push(`${svst}`)
				fs.writeFileSync(`./temp/audio/${svst}.mp3`, delb)
				fs.writeFileSync('./temp/vn.json', JSON.stringify(audionye))
				Lxa.sendMessage(from, `Sukses Menambahkan Audio\nCek dengan cara ${prefix}listvn`, MessageType.text, { quoted: mek })
				break

			case 'getvn':
				namastc = body.slice(7)
				try {
				buffer = fs.readFileSync(`./temp/audio/${namastc}.mp3`)
				Lxa.sendMessage(from, buffer, audio, { mimetype: 'audio/mp4', quoted: mek, ptt: true })
				} catch {
				  reply('Pacote não está registrado')
				}
				break

			case 'listvn':
			case 'vnlist':
				teks = '*List Vn:*\n\n'
				for (let awokwkwk of audionye) {
					teks += `- ${awokwkwk}\n`
				}
				teks += `\n*Total : ${audionye.length}*\nGunakan perintah\n*${prefix}getvn (nama pack)*\nuntuk mengambil vn`
				Lxa.sendMessage(from, teks.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": audionye } })
				break

			case 'addimg':
				if (!isQuotedImage) return reply('Marque a imagem')
				if (!isOwner) return reply(mess.only.ownerB)
				svst = body.slice(8)
				if (!svst) return reply('Qual é o nome da imagem')
				boij = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
				delb = await Lxa.downloadMediaMessage(boij)
				imagenye.push(`${svst}`)
				fs.writeFileSync(`./temp/foto/${svst}.jpeg`, delb)
				fs.writeFileSync('./temp/image.json', JSON.stringify(imagenye))
				Lxa.sendMessage(from, `Sucesso na adição de imagem\nVerificar pelo caminho ${prefix}listimg`, MessageType.text, { quoted: mek })
				break

			case 'getimg':
				namastc = body.slice(8)
				try {
				buffer = fs.readFileSync(`./temp/foto/${namastc}.jpeg`)
				Lxa.sendMessage(from, buffer, image, { quoted: mek, caption: `Result From Database : ${namastc}.jpeg` })
				} catch {
				  reply('Pacote não registrado')
				}
				break
				
			case 'listimg':
				teks = '*List Image :*\n\n'
				for (let awokwkwk of imagenye) {
					teks += `- ${awokwkwk}\n`
				}
				teks += `\n*Total : ${imagenye.length}*\nUse comandos\n*${prefix}getimg (nome do pacote)*\n para pegar uma foto`
				Lxa.sendMessage(from, teks.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": imagenye } })
				break

			case 'addvid':
			  if (!isOwner) return reply(mess.only.ownerB)
				if (!isQuotedVideo) return reply('Reply videonya')
				svst = body.slice(8)
				if (!svst) return reply('Nama videonya')
				boij = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
				delb = await Lxa.downloadMediaMessage(boij)
				videonye.push(`${svst}`)
				fs.writeFileSync(`./temp/video/${svst}.mp4`, delb)
				fs.writeFileSync('./temp/vid.json', JSON.stringify(videonye))
				Lxa.sendMessage(from, `Sukses Menambahkan Video\nCek dengan cara ${prefix}listvid`, MessageType.text, { quoted: mek })
				break

			case 'getvid':
				namastc = body.slice(8)
				try {
				buffer = fs.readFileSync(`./temp/video/${namastc}.mp4`)
				Lxa.sendMessage(from, buffer, video, { mimetype: 'video/mp4', quoted: mek })
				} catch {
				  reply('Pack tidak terdaftar')
				}
				break

			case 'listvid':
				teks = '*List Video :*\n\n'
				for (let awokwkwk of videonye) {
					teks += `- ${awokwkwk}\n`
				}
				teks += `\n*Total : ${videonye.length}*\nGunakan perintah\n*${prefix}getvid (nama pack)*\nuntuk mengambil video`
				Lxa.sendMessage(from, teks.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": videonye } })
				break


//----caklontong
  case 'caklontong':

anu = await fetchJson(`https://api.vhtear.com/funkuis&apikey=${vKey}`,
  {
method: 'get'
  })
if (!isRegister) return reply(mess.only.daftarB)
yup = anu.result.soal
jawab = anu.result.jawaban
alasam = anu.result.desk
setTimeout(() => {
  Lxa.sendMessage(from, `‣ *Jawaban* : ${jawab}\n‣ *Keterangn* : ${alasam}`, text, {
quoted: mek
  }) // ur cods
}, 30000) // 1000 = 1s,
setTimeout(() => {
  Lxa.sendMessage(from, '_10 mais segundos_', text) // ur cods
}, 20000) // 1000 = 1s,
setTimeout(() => {
  Lxa.sendMessage(from, '_20 Outro segundo_…', text) // ur cods
}, 10000) // 1000 = 1s,
setTimeout(() => {
  Lxa.sendMessage(from, text) // ur cods
}, 1000) // 1000 = 1s,
setTimeout(() => {

  Lxa.sendMessage(from, yup, text, {
quoted: mek
  }) // ur cods
}, 0) // 1000 = 1s,
break

//--stiker to video
  case 'tovid':
Lxa.updatePresence(from,
  Presence.composing)
if (!isRegister) return reply(mess.only.daftarB)
if (!isQuotedSticker) return reply('Marque a figurinha')
reply(mess.wait)
anumedia = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
anum = await Lxa.downloadAndSaveMediaMessage(anumedia)
ran = getRandom('.webp')
exec(`ffmpeg -i ${anum} ${ran}`, (err) => {
  fs.unlinkSync(anum)
  if (err) return reply('Falha ao converter a figurinha em vídeo')
  buffer = fs.readFileSync(ran)
  Lxa.sendMessage(from, buffer, video, {
quoted: mek, caption: 'É isso que vc queria?..'
  })
  fs.unlinkSync(ran)
})
break

//--mp4 to mp3
  case 'tomp3':
Lxa.updatePresence(from,
  Presence.composing)
if (!isRegister) return reply(mess.only.daftarB)
if (!isQuotedVideo) return reply('Marque o video')
reply(mess.wait)
mitri = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
duh = await Lxa.downloadAndSaveMediaMessage(mitri)
ran = getRandom('.mp4')
exec(`ffmpeg -i ${duh} ${ran}`, (err) => {
  fs.unlinkSync(duh)
  if (err) return reply('Falha ao converter vídeo para mp3')
  buffer = fs.readFileSync(ran)
  Lxa.sendMessage(from, buffer, audio, {
mimetype: 'audio/mp4', quoted: mek
  })
  fs.unlinkSync(ran)
})
break

//---random fakta
case 'fakta':
					anu = await fetchJson(`https://api.arugaz.my.id/api/random/text/faktaunik`, {method: 'get'})
					fakta = `Faktanya: ${anu.result}`
					Lxa.sendMessage(from, fakta, text, {quoted: mek})
break

//--Tebak gambar
  case 'tebakgambar':

anu = await fetchJson(`https://api.vhtear.com/tebakgambar&apikey=${vKey}`, {
  method: 'get'
})
if (!isRegister) return reply(mess.only.daftarB)
buffer = await getBuffer(anu.result.soalImg)
jawab = anu.result.jawaban
setTimeout(() => {
  Lxa.sendMessage(from, `*➸ Jawaban :* ${jawab}`, text, {
quoted: mek
  }) // ur cods
}, 30000) // 1000 = 1s,
setTimeout(() => {
  Lxa.sendMessage(from, '_10 detik lagi_', text) // ur cods
}, 20000) // 1000 = 1s,
setTimeout(() => {
  Lxa.sendMessage(from, '_20 Detik lagi_…', text) // ur cods
}, 10000) // 1000 = 1s,
setTimeout(() => {
  Lxa.sendMessage(from, text) // ur cods
}, 1000) // 1000 = 1s,
setTimeout(() => {

  Lxa.sendMessage(from, buffer, image, {
quoted: mek, caption: 'APA HAYOO'
  }) // ur cods
}, 0) // 1000 = 1s,
break


//--google voice
				case 'tts':
					if (args.length < 1) return Lxa.sendMessage(from, 'Qual é o código da linguagem?', text, {quoted: mek})
					const gtts = require('./lib/gtts')(args[0])
					if (args.length < 2) return Lxa.sendMessage(from, 'Cadê o texto moço?', text, {quoted: mek})
					dtt = body.slice(8)
					ranm = getRandom('.mp3')
					dtt.length > 600
					? reply('A maior parte do texto é mn')
					: gtts.save(ranm, dtt, function() {
						Lxa.sendMessage(from, fs.readFileSync(ranm), audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
						fs.unlinkSync(ranm)
					})
					break

//-- Setting prefix
				case 'setprefix':
					if (args.length < 1) return
					if (!isOwner) return reply(mess.only.ownerB)
				  prefix = args[0]
					up.prefix = prefix
					fs.writeFileSync('./data/settings.json', JSON.stringify(up, null, '\t'))
					reply(`Prefix berhasil di ubah menjadi : ${prefix}`)
					break


case 'block':
  Lxa.updatePresence(from, Presence.composing)
  if (!isGroup) return reply(mess.only.group)
  if (!isOwner) return reply(mess.only.ownerB)
  Lxa.blockUser (`${body.slice(8)}@c.us`, "add")
  Lxa.sendMessage(from, `comando recebido, Contsto Bloqueado`, text, {
quoted: mek
  })
  break

//membuka blokir
case 'unblock':
  if (!isGroup) return reply(mess.only.group)
  if (!isOwner) return reply(mess.only.ownerB)
  Lxa.blockUser (`${body.slice(9)}@c.us`, "remove")
  Lxa.sendMessage(from, `Pedido Recebido, Desbloqueado`, text)
  break


//--Hilih maker
				case 'hilih':
					if (args.length < 1) return reply('Masukan text')
					try {
					anu = await fetchJson(`https://mhankbarbars.herokuapp.com/api/hilih?teks=${body.slice(7)}`, {method: 'get'})
					reply(anu.result)
					} catch {
					  reply(mess.ferr)
					}
					break

				case 'tiktokstalk':
					try {
						if (args.length < 1) return Lxa.sendMessage(from, 'Usernamenya mana um?', text, {quoted: mek})
						let { user, stats } = await tiktod.getUserProfileInfo(args[0])
						reply(mess.wait)
						teks = `*ID* : ${user.id}\n*Username* : ${user.uniqueId}\n*Nickname* : ${user.nickname}\n*Followers* : ${stats.followerCount}\n*Followings* : ${stats.followingCount}\n*Posts* : ${stats.videoCount}\n*Luv* : ${stats.heart}\n`
						buffer = await getBuffer(user.avatarLarger)
						Lxa.sendMessage(from, buffer, image, {quoted: mek, caption: teks})
					} catch (e) {
						console.log(`Error :`, color(e,'red'))
						reply('Kemungkinan username tidak valid')
					}
					break
				case 'nulis':
				case 'tulis':
				if (args.length < 1) return reply(`Onde está o texto moço? Exemplo : ${prefix}nulis Wendel lindo opaeae`)
				nul = body.slice(7)
				reply('「❗」ESPERE')
				tak = await getBuffer(`https://api.zeks.xyz/api/nulis?text=${nul}&apikey=apivinz`)
				Lxa.sendMessage(from, tak, image, {quoted: mek, caption: 'Melhor escrever você mesmo :*'})
					break
				case 'url2img':
					tipelist = ['desktop','tablet','mobile']
					if (args.length < 1) return reply('Tipenya apa um?')
					if (!tipelist.includes(args[0])) return reply('Tipe desktop|tablet|mobile')
					if (args.length < 2) return reply('Urlnya mana um?')
					if (!isUrl(args[1])) return reply(mess.error.Iv)
					reply(mess.wait)
					anu = await fetchJson(`https://mhankbarbar.tech/api/url2image?tipe=${args[0]}&url=${args[1]}&apiKey=${BarBarKey}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					buff = await getBuffer(anu.result)
					Lxa.sendMessage(from, buff, image, {quoted: mek})
					break
				case 'ttp':
				if (!isRegister) return reply(mess.only.daftarB)
					if (args.length < 1) return reply('Textnya mana um?')
					ranp = getRandom('.png')
					rano = getRandom('.webp')
					teks = body.slice(5).trim()
					anu = await fetchJson(`https://mhankbarbar.tech/api/text2image?text=${teks}&apiKey=${BarBarKey}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					exec(`wget ${anu.result} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
						fs.unlinkSync(ranp)
						if (err) return reply(mess.error.stick)
						exec(`webpmux -set exif ${addMetadata('Lexa', 'Mrf.zvx')} ${rano} -o ${rano}`, async (error) => {
							if (error) return reply(mess.error.stick)
							Lxa.sendMessage(from, fs.readFileSync(rano), sticker, {quoted: mek})
							fs.unlinkSync(rano)
						})
					})
					break

//---Tagall member
				case 'tagall':
Lxa.updatePresence(from, Presence.composing)
if (!isGroup) return reply(mess.only.group)
if (!isRegister) return reply(mess.only.daftarB)
if (!isGroupAdmins) return reply(mess.only.admin)
members_id = []
teks = (args.length > 1) ? body.slice(8).trim(): ''
teks += `  Total : ${groupMembers.length}\n`
for (let mem of groupMembers) {
  teks += `┃ @${mem.jid.split('@')[0]}\n`
  members_id.push(mem.jid)
}
mentions('〘  *TAGALL* 〙\n┏━━━━━━━━━━━━━━━━━━━━\n┠⊷'+teks+'┃━━━━━━━━━━━━━━━━━━━━\n┃────✪ LEXA BOT ✪────\n┗━━━━━━━━━━━━━━━━━━━━', members_id, true)
break


//clear all chat
				case 'clearall':
					if (!isOwner) return reply('Quem é Você?')
					anu = await Lxa.chats.all()
					Lxa.setMaxListeners(25)
					for (let _ of anu) {
						Lxa.deleteChat(_.jid)
					}
					reply('Pronto, Todos os chats deletados :)')
					break
				case 'bc':
					if (!isOwner) return reply('Kamu siapa?')
					if (args.length < 1) return reply('.......')
					anu = await Lxa.chats.all()
					if (isMedia && !mek.message.videoMessage || isQuotedImage) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						buff = await Lxa.downloadMediaMessage(encmedia)
						for (let _ of anu) {
							Lxa.sendMessage(_.jid, buff, image, {caption: `*${body.slice(4)}*`})
						}
						reply('Suksess broadcast')
					} else {
						for (let _ of anu) {
							sendMess(_.jid, `*${body.slice(4)}*`)
						}
						reply('Suksess broadcast')
					}
					break

//--menaikan jabatan
      case 'promote':
      case 'promover':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = 'Promovido com sucesso\n'
						for (let _ of mentioned) {
							teks += `@${_.split('@')[0]}\n`
						}
						mentions(from, mentioned, true)
						Lxa.groupRemove(from, mentioned)
					} else {
						mentions(`Promovido com sucesso @${mentioned[0].split('@')[0]} agora é administrador do grupo!`, mentioned, true)
						Lxa.groupMakeAdmin(from, mentioned)
					}
					break

  //ganti nama grup
case 'loli2':
            if (!isRegister) return reply(mess.only.daftarB)
            if (isLimit(sender)) return reply(mess.limitend)
           res = await fetchJson(`https://tobz-api.herokuapp.com/api/randomloli?apikey=BotWeA`, {method: 'get'})
           buffer = await getBuffer(res.result)
           Lxa.sendMessage(from, buffer, image, {quoted: mek, caption: '*LOLI É VIDA*'})
		await limitAdd(sender)
		break
  case 'setname':
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return reply(mess.only.admin)
if (!isBotGroupAdmins) return reply(mess.only.Badmin)
idgrup = `${from.split("@s.whatsapp.net")[0]}`;
Lxa.groupUpdateSubject(idgrup, `${body.slice(9)}`)
Lxa.sendMessage(from, 'Nome do grupo alterado', text, {
  quoted: mek
})
break

  //ganti desk
  case 'setdesk':
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return reply(mess.only.admin)
if (!isBotGroupAdmins) return reply(mess.only.Badmin)
Lxa.groupUpdateDescription(from, `${body.slice(9)}`)
Lxa.sendMessage(from, ' Descrição alterada com sucesso ', text, {
  quoted: mek
})
break

//--menurunkan jabatan
				case 'demote':
				case 'rebaixar':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = 'Rebaixado com sucesso\n'
						for (let _ of mentioned) {
							teks += `@${_.split('@')[0]}\n`
						}
						mentions(teks, mentioned, true)
						Lxa.groupRemove(from, mentioned)
					} else {
						mentions(`Rebaixado com sucesso @${mentioned[0].split('@')[0]} agora é membro comum!`, mentioned, true)
						Lxa.groupDemoteAdmin(from, mentioned)
					}
					break

//--menambah member
				case 'add':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					if (args.length < 1) return reply('Insira o número')
					if (args[0].startsWith('08')) return reply('Use o código do país sem o "+" é isso')
					try {
						num = `${args[0].replace(/ /g, '')}@s.whatsapp.net`
						Lxa.groupAdd(from, [num])
					} catch (e) {
						console.log('Error :', e)
						reply('Falha ao adicionar destino, talvez porque é privado')
					}
					break

//--mengeluarkan member
				case 'kick':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Tag target')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = 'Pedidos recebidos, emitidos :\n'
						for (let _ of mentioned) {
							teks += `@${_.split('@')[0]}\n`
						}
						mentions(teks, mentioned, true)
						Lxa.groupRemove(from, mentioned)
					} else {
						mentions(`Pedidos recebidos, emitidos : @${mentioned[0].split('@')[0]}`, mentioned, true)
						Lxa.groupRemove(from, mentioned)
					}
					break

//--list admin grup
				case 'listadmins':
				  case 'listadmin':
				    case 'adminlist':
					if (!isGroup) return reply(mess.only.group)
					teks = `Lista admin do grupo *${groupMetadata.subject}*\nTotal : ${groupAdmins.length}\n\n`
					no = 0
					for (let admon of groupAdmins) {
						no += 1
						teks += `[${no.toString()}] @${admon.split('@')[0]}\n`
					}
					mentions(teks, groupAdmins, true)
					break

//--ganti pp bot
case 'setppbot':
  Lxa.updatePresence(from, Presence.composing)
  if (!isOwner) return reply(mess.only.ownerB)
  const botpp = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contxtInfo: mek
  const cuk = await Lxa.downloadAndSaveMediaMessage(botpp)
  await Lxa.updateProfilePicture(botNumber, cuk)
  reply('Obrigado pelo novo perfil😗')
  break
//--Mengambil link grup
    case 'linkgroup':
    case 'linkgc':
        if (!isGroup) return reply(mess.only.group)
        if (!isGroupAdmins) return reply(mess.only.admin)
        if (!isBotGroupAdmins) return reply(mess.only.Badmin)
        linkgc = await Lxa.groupInviteCode(from)
        reply('https://chat.whatsapp.com/'+linkgc)
                    break

//--Mengeluarkan bot
      case 'leave':
      if (!isGroup) return reply(mess.only.group)
					if (!isOwner) return reply('Blz fale cmg mais não')
                    break

//--Convert stiker to image
				case 'toimg':
					if (!isQuotedSticker) return reply('Marque a figurinha')
					if (!isRegister) return reply(mess.only.daftarB)
					reply(mess.wait)
					imgmed = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					medimg = await Lxa.downloadAndSaveMediaMessage(imgmed)
					ran = getRandom('.png')
					exec(`ffmpeg -i ${medimg} ${ran}`, (err) => {
						fs.unlinkSync(medimg)
						if (err) return reply('Gagal')
						buffer = fs.readFileSync(ran)
						Lxa.sendMessage(from, buffer, image, {quoted: mek, caption: 'e isso?'})
						fs.unlinkSync(ran)
					})
					break


//--arti mimpi
  case 'artimimpi':
aruga = body.slice(11)
if (!isRegister) return reply(mess.only.daftarB)
if (args.length < 1) return reply(`Que sonho é esse ?\nExemplo: ${prefix}artimimpi cobra`)
try {
anu = await fetchJson(`https://videfikri.com/api/primbon/artimimpi/?mimpi=${aruga}`, {
  method: 'get'
})
reply(anu.result.artimimpi)
await limitAdd(sender)
} catch {
  reply('Sepertinya fitur sedang eror')
}
break

//--Simsimi talk
				case 'simi':
					if (args.length < 1) return reply(`Oii ${pushname}`)
					teks = body.slice(6)
					try { 
					anu = await fetchJson(`https://api.xteam.xyz/simsimi?kata=${teks}&APIKEY=${xKey}`, {method: 'get'})
					if (anu.error) return reply('Simi não sabe oq é isso')
					reply(anu.jawaban)
					} catch {
					  reply(mess.ferr)
					}
					break

case 'bot':
					if (args.length < 1) return reply(`Oii ${pushname}`)
					teks = body.slice(5)
					try { 
					anu = await fetchJson(`https://simsumi.herokuapp.com/api?text=${teks}`, {method: 'get'})
					if (anu.error) return reply('Simi não sabe oq é isso ')
					reply(anu.jawaban)
					} catch {
					  reply(mess.ferr)
					}
					break

//--Verifkasi
case 'verify':
case 'rg':
  case 'register':
if (isRegister) return reply('sua conta foi verificada')
const namaUser = `${pushname}`
const umurUser = `${sender}`
const serialUser = createSerial(20)
veri = sender
if (isGroup) {
  addRegisteredUser(sender, namaUser, umurUser, time, serialUser)
  hasil = `〘  *DADOS DE REGISTRO* 〙
Código : *${serialUser}*
╔─────────────────────
╠≽️ *Nome* : *${namaUser}*
╠≽️ *Número* : *${sender.split("@")[0]}*
╚─────────────────────`
reply(hasil)
  console.log(color('[REGISTER]'), color(time, 'yellow'), 'Name:', color(namaUser, 'cyan'), 'Age:', color(umurUser, 'cyan'), 'Serial:', color(serialUser, 'cyan'), 'in', color(sender || groupName))
} else {
  addRegisteredUser(sender, namaUser, umurUser, time, serialUser)
  hasil = `〘  *DADOS DE REGISTRO* 〙
Código : *${serialUser}*
╔─────────────────────
╠≽️ *Nome* : *${namaUser}*
╠≽️ *Número* : *${sender.split("@")[0]}*
╚─────────────────────`
reply(hasil)
  console.log(color('[REGISTER]'), color(time, 'yellow'), 'Name:', color(namaUser, 'cyan'), 'Age:', color(umurUser, 'cyan'), 'Serial:', color(serialUser, 'cyan'))
}
tm = `a verificação está completa, digite ${prefix}Menu para exibir a lista do menu`
reply(tm)
break

//--grup semua peserta
case 'closegc':
  Lxa.updatePresence(from, Presence.composing)
  if (!isGroup) return reply(mess.only.group)
  if (!isGroupAdmins) return reply(mess.only.admin)
  if (!isBotGroupAdmins) return reply(mess.only.Badmin)
  var nomor = mek.participant
  const close = {
text: `Grupo fechado pelo administrador @${nomor.split("@s.whatsapp.net")[0]}\nagora * apenas administradores* podem enviar mensagens`,
contextInfo: {
  mentionedJid: [nomor]
}
  }
  Lxa.groupSettingChange (from, GroupSettingChange.messageSend, true);
  reply(close)
  break

//--grup hanya admin
case 'opengc':
  case 'bukagc':
Lxa.updatePresence(from, Presence.composing)
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return reply(mess.only.admin)
if (!isBotGroupAdmins) return reply(mess.only.Badmin)
open = {
  text: `Grupo aberto pelo administrador @${sender.split("@")[0]}\nagora *todos os participantes* podem enviar mensagens`,
  contextInfo: {
mentionedJid: [sender]
  }
}
Lxa.groupSettingChange (from, GroupSettingChange.messageSend, false)
Lxa.sendMessage(from, open, text, {
  quoted: mek
})
break

//---mengahapus pesan bot
case 'delete':
  case 'del':
  case 'apagar':
if (!isGroup)return reply(mess.only.group)
if (!isRegister) return reply(mess.only.daftarB)
if (!isGroupAdmins)return reply(mess.only.admin)
try {
Lxa.deleteMessage(from, {
  id: mek.message.extendedTextMessage.contextInfo.stanzaId, remoteJid: from, fromMe: true
})
} catch {
  reply('so posso apagar msg que eu enviei ')
}
break

//--jeitoso cekkkk
  case 'gantengcek':
if (args.length < 1) return reply('Insira o nome do alvo')
ganteng = body.slice(12)
const gan = ['10',
  '30',
  '20',
  '40',
  '50',
  '60',
  '70',
  '62',
  '74',
  '83',
  '97',
  '100',
  '29',
  '94',
  '75',
  '82',
  '41',
  '39']
const teng = gan[Math.floor(Math.random() * gan.length)]
Lxa.sendMessage(from, 'Jeitoso : *'+ganteng+'*\n\nResposta : '+ teng+'%', text, {
  quoted: mek
})
break

//--Bonito cekk
  case 'cantikcek':
if (args.length < 1) return reply('Insira o nome do alvo')
cantik = body.slice(12)
const can = ['10',
  '30',
  '20',
  '40',
  '50',
  '60',
  '70',
  '62',
  '74',
  '83',
  '97',
  '100',
  '29',
  '94',
  '75',
  '82',
  '41',
  '39']
const tik = can[Math.floor(Math.random() * can.length)]
Lxa.sendMessage(from, 'O quão bonito vc é *'+cantik+'*\n\nResultado : '+ tik+'%', text, {
  quoted: mek
})
break



				case 'welcome':
				case 'bemvindo':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (args.length < 1) return reply('obg man')
					if (Number(args[0]) === 1) {
						if (isWelkom) return reply('Já ta ativo mn')
						welkom.push(from)
						fs.writeFileSync('./data/welkom.json', JSON.stringify(welkom))
						reply('Ativadk o recurso de boas-vindas neste grupo✔️')
					} else if (Number(args[0]) === 0) {
						welkom.splice(from, 1)
						fs.writeFileSync('./data/welkom.json', JSON.stringify(welkom))
						reply('Desativado o recurso de boas-vindas neste grupo ✔️')
					} else {
						reply('1 para ativar, 0 para desativar')
					}
                                      break
				case 'clone':
					if (!isGroup) return reply(mess.only.group)
					if (!isOwner) return reply(mess.only.ownerB)
					if (args.length < 1) return reply('Marque')
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Tag cvk')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					let { jid, id, notify } = groupMembers.find(x => x.jid === mentioned)
					try {
						pp = await Lxa.getProfilePicture(id)
						buffer = await getBuffer(pp)
						Lxa.updateProfilePicture(botNumber, buffer)
						mentions(`Foto do perfil atualizada com sucesso usando a foto do perfil @${id.split('@')[0]}`, [jid], true)
					} catch (e) {
						reply(' falha')
					}
					break
				case 'wait':
					if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						reply(mess.wait)
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
      const media = await Lxa.downloadMediaMessage(encmedia)
						await wait(media).then(res => {
							Lxa.sendMessage(from, res.video, video, {quoted: mek, caption: res.teks.trim()})
						}).catch(err => {
							reply(err)
						})
					} else {
						reply('Foto aja mas')
					}
					break

// SOUND					

case 'yamate':
if (isLimit(sender)) return reply(mess.limitend)
puluh = fs.readFileSync('./assets/yamate.mp3');
Lxa.sendMessage(from, puluh, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
await limitAdd(sender)
break	
				default:
 if (budy.includes('Darin')) {
 const bot = fs.readFileSync('./assets/bot');
 Lxa.sendMessage(from, bot, MessageType.sticker, {quoted: mek})
  }
		if (budy.includes(`Thanks`)) {
                  reply(`Sama Sama Kak😁`)
                  }
if (budy.includes(`terimakasih`)) {
                  reply(`Sama Sama dek😁`)
                  }
		if (budy.includes(`Makasih`)) {
                  reply(`Sama Sama dek😁`)
                  }
				if (body.startsWith(`${prefix}${command}`)) {
  reply(`        ────────────────\nOii *${pushname}* !!!\no Comando : *${prefix}${command}*\nao existe digite *${prefix}Menu* para ver os comandos\n        ────────────────`)
				}
					if (isGroup && isSimi && budy != undefined) {
						console.log(budy)
						muehe = await simih(budy)
						console.log(muehe)
						reply(muehe)
					} else {
						return //console.log(color('[WARN]','red'), 'Unregistered Command from', color(sender.split('@')[0]))
					}
                           }
		} catch (e) {
			console.log('Error : %s', color(e, 'green'))
		}
	})
}
starts()
