const help = (pushname, prefix, botName, ownerName, reqXp, uangku) => {
        return `
「 *${botName}* 」

◪ *USER INFO*
  ❏ Name: ${pushname}
  ❏ XP: ${reqXp}
  ❏ Money: ${uangku}
  ❏ Registered: ✔️
◪ *BOT INFO*
  ❏ Prefix: 「  ${prefix}  」
  ❏ Creator: ${ownerName}
  ❏ Version: 0.0.4
◪ *ABOUT*
  │
  ├─ ❏ ${prefix}info
  ├─ ❏ ${prefix}blocklist
  ├─ ❏ ${prefix}chatlist   EM TESTE
  ├─ ❏ ${prefix}ping
  └─ ❏ ${prefix}bugreport  EM TESTE
◪ *MENU*
  │
  ├─ ❏ ${prefix}sticker
  ├─ ❏ ${prefix}stickergif
  ├─ ❏ ${prefix}gay
  ├─ ❏ ${prefix}play
  ├─ ❏ ${prefix}afk
  ├─ ❏ ${prefix}tiktokstalk
  ├─ ❏ ${prefix}dono
  ├─ ❏ ${prefix}clone
  ├─ ❏ ${prefix}testime
  ├─ ❏ ${prefix}pinterest
  └─ ❏ ${prefix}limpar
◪ *GROUP*
  │
  ├─ ❏ ${prefix}abrirgp
  ├─ ❏ ${prefix}fechargp
  ├─ ❏ ${prefix}promover
  ├─ ❏ ${prefix}rebaixar
  ├─ ❏ ${prefix}marca
  ├─ ❏ ${prefix}marcar2
  ├─ ❏ ${prefix}marcar3
  ├─ ❏ ${prefix}marcar4
  ├─ ❏ ${prefix}marcar5
  ├─ ❏ ${prefix}add
  ├─ ❏ ${prefix}setname
  ├─ ❏ ${prefix}setdesc
  ├─ ❏ ${prefix}ftbot
  ├─ ❏ ${prefix}kick
  ├─ ❏ ${prefix}listadmins
  ├─ ❏ ${prefix}link
  ├─ ❏ ${prefix}botfdp
  ├─ ❏ ${prefix}welcome
  ├─ ❏ ${prefix}apagar
  └─ ❏ ${prefix}donodogrupo
◪ *LIMIT*
  │
  ├─ ❏ ${prefix}limite
  ├─ ❏ ${prefix}mochila
  └─ ❏ ${prefix}comprarlimite

Nota: Você pode comprar limites recolhendo dinheiro primeiro. Verifique seu dinheiro digitando o comando *${prefix}bal*, o preço de 1 limite = 1000 dinheiro.

  ◪ *XP*
  │
  ├─ ❏ ${prefix}leveling
  ├─ ❏ ${prefix}level
  ├─ ❏ ${prefix}evento
  └─ ❏ ${prefix}minerar`
}
exports.help = help
