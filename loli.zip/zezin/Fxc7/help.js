// menu fitur bot
const help = (prefix, instagram, yt, name, pushname2, user, limitt, uptime, jam, tanggal) => { 
	return `


╭──────「 *REGULATION ${name}* 」
┴
┣⊱  \`\`\`NOME DO USUARIO:\`\`\` *${pushname2}*
┣⊱  \`\`\`VERIFICADO:\`\`\` ✅
┣⊱  \`\`\`LIMITE:\`\`\` *${limitt} DIARIO*
┣⊱  \`\`\`ATIVO:\`\`\` ${kyun(uptime)}
┣⊱  \`\`\`JAM:\`\`\` *${jam} WIB*
┣⊱  \`\`\`mes:\`\`\` *${tanggal}*
┣⊱  \`\`\`VERSAO:\`\`\` *3.0.0*
┣⊱  \`\`\`USE TERDAFTAR:\`\`\` *${user.length} User*
┬
╰────────────────────────


╭──────「 *SOBRE ${name}* 」
┴
│➻ *${prefix}report 
│➻ *${prefix}speed*
│➻ *${prefix}daftar*
│➻ *${prefix}totaluser*
│➻ *${prefix}grouplist*
│➻ *${prefix}blocklist*
│➻ *${prefix}banlist*
│➻ *${prefix}premiumlist*
┬
╰────────────────────────

╭──────「 *MENU* 」
┴
│➻ *${prefix}nulis Nome/Sobrenome/texto*
│➻ *${prefix}tts pt texto*
│➻ *${prefix}sticker*
│➻ *${prefix}gifsticker*
│➻ *${prefix}toimg*
│➻ *${prefix}img2url*
│➻ *${prefix}tomp3*
│➻ *${prefix}persengay @𝑚𝑎𝑟𝑞𝑢𝑒
┬
╰──────────────────────────

╭───────「 *𝐴𝑃𝐸𝑁𝐴𝑆 𝐸𝑀 𝐺𝑅𝑈𝑃𝑂* 」
┴
│➻ *${prefix}welcome On/Off*
│➻ *${prefix}grup buka/tutup*
│➻ *${prefix}antilink on/off*
│➻ *${prefix}ownergrup*
│➻ *${prefix}setpp*
│➻ *${prefix}infogc*
│➻ *${prefix}add 55𝑋𝑋𝑋𝑋𝑋𝑋*
│➻ *${prefix}kick @𝑚𝑎𝑟𝑞𝑢𝑒 𝑜 𝑓𝑑𝑝*
│➻ *${prefix}kicktime @𝑚𝑎𝑟𝑞𝑢𝑒 𝑜 𝑓𝑑𝑝*
│➻ *${prefix}promote @𝑚𝑎𝑟𝑞𝑢𝑒 𝑜 𝑓𝑑𝑝*
│➻ *${prefix}demote @𝑚𝑎𝑟𝑞𝑢𝑒 𝑜 𝑓𝑑𝑝*
│➻ *${prefix}setname*
│➻ *${prefix}setdesc*
│➻ *${prefix}linkgrup*
│➻ *${prefix}tagme*
│➻ *${prefix}hidetag*
│➻ *${prefix}tagall*
│➻ *${prefix}mentionall*
│➻ *${prefix}listadmin*
┬
╰──────────────────────── 

╭─────────「 *𝑺Ó 𝑷𝑹𝑶𝑷𝑹𝑰𝑬𝑻𝑨𝑹𝑰𝑶* 」
┴
│➻ *${prefix}addprem @𝑚𝑎𝑟𝑞𝑢𝑒*
│➻ *${prefix}removeprem @𝑚𝑎𝑟𝑞𝑢𝑒*
│➻ *${prefix}setmemlimit*
│➻ *${prefix}setreply*
│➻ *${prefix}setprefix*
│➻ *${prefix}setnamebot*
│➻ *${prefix}setppbot*
│➻ *${prefix}bc*
│➻ *${prefix}bcgc*
│➻ *${prefix}ban*
│➻ *${prefix}unban*
│➻ *${prefix}block*
│➻ *${prefix}unblock*
│➻ *${prefix}clearall*
│➻ *${prefix}delete*
│➻ *${prefix}clone*
│➻ *${prefix}getses*
│➻ *${prefix}leave*
┬
╰────────────────────────


╭────────「 *𝑷𝑹𝑬𝑴𝑰𝑼𝑴 𝑨𝑷𝑬𝑵𝑨𝑺* 」
┴
│➻ *${prefix}playmp3 Nome da musica*
┬
╰────────────────────────`
}

exports.help = help

// penghitung aktif bot
function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);
  return `*${pad(hours)} Hora ${pad(minutes)} minutos ${pad(seconds)} segundos*`
}

// donasi menu
const donasi = (name) => { 
	return `       
╭─────「 *DONASI SEIKHLASNYA* 」
┴
│√ *PULSA: 08311800241*
│√ *OVO : 08311800241*
┬
╰──────「 *BY ${name}* 」

`
}
exports.donasi = donasi

// bahasa list
const bahasa = (prefix) => {
return `
List Bahasa Untuk Command *${prefix}tts*

  af: Afrikaans
  sq: Albanian
  ar: Arabic
  hy: Armenian
  ca: Catalan
  zh: Chinese
  zh-cn: Chinese (Mandarin/China)
  zh-tw: Chinese (Mandarin/Taiwan)
  zh-yue: Chinese (Cantonese)
  hr: Croatian
  cs: Czech
  da: Danish
  nl: Dutch
  en: English
  en-au: English (Australia)
  en-uk: English (United Kingdom)
  en-us: English (United States)
  eo: Esperanto
  fi: Finnish
  fr: French
  de: German
  el: Greek
  ht: Haitian Creole
  hi: Hindi
  hu: Hungarian
  is: Icelandic
  id: Indonesian
  it: Italian
  ja: Japanese
  ko: Korean
  la: Latin
  lv: Latvian
  mk: Macedonian
  no: Norwegian
  pl: Polish
  pt: Portuguese
  pt-br: Portuguese (Brazil)
  ro: Romanian
  ru: Russian
  sr: Serbian
  sk: Slovak
  es: Spanish
  es-es: Spanish (Spain)
  es-us: Spanish (United States)
  sw: Swahili
  sv: Swedish
  ta: Tamil
  th: Thai
  tr: Turkish
  vi: Vietnamese
  cy: Welsh
`
}
exports.bahasa = bahasa

// Limit
const limitend = (pushname2) => {
        return`*Desculpe ${pushname2} O limite de hoje expirou*\n*o limite é redefinido a cada 12:00*`
}

const limitcount = (limitCounts) => {
        return`
${limitCounts}
`
}

exports.limitend = limitend
exports.limitcount = limitcount
